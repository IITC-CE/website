// ==UserScript==
// @author         cradle
// @name           IITC plugin: User Location
// @category       Tweaks
// @version        0.3.1.20260504.112538
// @description    Show user location marker on map
// @id             user-location
// @namespace      https://github.com/IITC-CE/ingress-intel-total-conversion
// @updateURL      https://iitc.app/build/artifact/PR916/plugins/user-location.meta.js
// @downloadURL    https://iitc.app/build/artifact/PR916/plugins/user-location.user.js
// @match          https://intel.ingress.com/*
// @match          https://intel-x.ingress.com/*
// @icon           https://iitc.app/extras/plugin-icons/user-location.svg
// @grant          none
// ==/UserScript==
