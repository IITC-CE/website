// ==UserScript==
// @author         jonatkins
// @name           IITC plugin: Blank map
// @category       Map Tiles
// @version        0.1.6.20260426.182857
// @description    Add a blank map layer - no roads or other features.
// @id             basemap-blank
// @namespace      https://github.com/IITC-CE/ingress-intel-total-conversion
// @updateURL      https://iitc.app/build/artifact/PR909/plugins/basemap-blank.meta.js
// @downloadURL    https://iitc.app/build/artifact/PR909/plugins/basemap-blank.user.js
// @match          https://intel.ingress.com/*
// @match          https://intel-x.ingress.com/*
// @icon           https://iitc.app/extras/plugin-icons/basemap-blank.svg
// @grant          none
// ==/UserScript==
