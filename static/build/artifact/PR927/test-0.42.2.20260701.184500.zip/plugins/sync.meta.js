// ==UserScript==
// @author         xelio
// @name           IITC plugin: Sync
// @category       Misc
// @version        0.6.0.20260701.184500
// @description    Sync data between clients via Google Drive API. Only syncs data from specific plugins (currently: Keys, Bookmarks, Uniques). Sign in via the 'Sync' link. Data is synchronized every 3 minutes.
// @id             sync
// @namespace      https://github.com/IITC-CE/ingress-intel-total-conversion
// @updateURL      https://iitc.app/build/artifact/PR927/plugins/sync.meta.js
// @downloadURL    https://iitc.app/build/artifact/PR927/plugins/sync.user.js
// @match          https://intel.ingress.com/*
// @match          https://intel-x.ingress.com/*
// @icon           https://iitc.app/extras/plugin-icons/sync.svg
// @grant          none
// ==/UserScript==
