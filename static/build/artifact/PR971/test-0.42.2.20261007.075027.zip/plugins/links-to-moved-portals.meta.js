// ==UserScript==
// @author         screach
// @name           IITC plugin: Links to moved portals
// @category       Layer
// @version        0.1.2.20261007.075027
// @description    Show links to portals with different location data
// @id             links-to-moved-portals
// @namespace      https://github.com/IITC-CE/ingress-intel-total-conversion
// @updateURL      https://iitc.app/build/artifact/PR971/plugins/links-to-moved-portals.meta.js
// @downloadURL    https://iitc.app/build/artifact/PR971/plugins/links-to-moved-portals.user.js
// @match          https://intel.ingress.com/*
// @match          https://intel-x.ingress.com/*
// @icon           https://iitc.app/extras/plugin-icons/links-to-moved-portals.svg
// @grant          none
// ==/UserScript==
