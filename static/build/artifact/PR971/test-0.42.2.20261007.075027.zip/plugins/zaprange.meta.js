// ==UserScript==
// @author         ZasoGD
// @name           IITC plugin: Zaprange
// @category       Layer
// @version        0.1.9.20261007.075027
// @description    Shows the maximum range of attack by the portals.
// @id             zaprange
// @namespace      https://github.com/IITC-CE/ingress-intel-total-conversion
// @updateURL      https://iitc.app/build/artifact/PR971/plugins/zaprange.meta.js
// @downloadURL    https://iitc.app/build/artifact/PR971/plugins/zaprange.user.js
// @match          https://intel.ingress.com/*
// @match          https://intel-x.ingress.com/*
// @icon           https://iitc.app/extras/plugin-icons/zaprange.svg
// @grant          none
// ==/UserScript==
