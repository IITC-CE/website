// ==UserScript==
// @author         fragger
// @name           IITC plugin: Zoom slider
// @category       Controls
// @version        0.2.4.20261013.095146
// @description    Show a zoom slider on the map instead of the zoom buttons.
// @id             zoom-slider
// @namespace      https://github.com/IITC-CE/ingress-intel-total-conversion
// @updateURL      https://iitc.app/build/artifact/PR979/plugins/zoom-slider.meta.js
// @downloadURL    https://iitc.app/build/artifact/PR979/plugins/zoom-slider.user.js
// @match          https://intel.ingress.com/*
// @match          https://intel-x.ingress.com/*
// @icon           https://iitc.app/extras/plugin-icons/zoom-slider.svg
// @grant          none
// ==/UserScript==
