// ==UserScript==
// @author         jonatkins
// @name           IITC plugin: OpenStreetMap.org map
// @category       Map Tiles
// @version        0.1.6.20261013.103109
// @description    Add the native OpenStreetMap.org map tiles as an optional layer.
// @id             basemap-openstreetmap
// @namespace      https://github.com/IITC-CE/ingress-intel-total-conversion
// @updateURL      https://iitc.app/build/artifact/PR979/plugins/basemap-openstreetmap.meta.js
// @downloadURL    https://iitc.app/build/artifact/PR979/plugins/basemap-openstreetmap.user.js
// @match          https://intel.ingress.com/*
// @match          https://intel-x.ingress.com/*
// @icon           https://iitc.app/extras/plugin-icons/basemap-openstreetmap.svg
// @grant          none
// ==/UserScript==
