// ==UserScript==
// @name           IITC plugin: Machina Tools
// @author         Perringaiden
// @category       Misc
// @version        0.9.3.20260917.102326
// @description    Machina investigation tools - 2 new layers to see possible Machina spread and portal detail links to display Machina cluster information and to navigate to parent or seed Machina portal
// @id             machina-tools
// @namespace      https://github.com/IITC-CE/ingress-intel-total-conversion
// @updateURL      https://iitc.app/build/artifact/PR965/plugins/machina-tools.meta.js
// @downloadURL    https://iitc.app/build/artifact/PR965/plugins/machina-tools.user.js
// @match          https://intel.ingress.com/*
// @match          https://intel-x.ingress.com/*
// @icon           https://iitc.app/extras/plugin-icons/machina-tools.svg
// @grant          none
// ==/UserScript==
