// ==UserScript==
// @author         vita10gy
// @name           IITC plugin: Highlight portals by my level
// @category       Highlighter
// @version        0.2.3.20260917.102326
// @description    Use the portal fill color to denote if the portal is either at and above, or at and below your level.
// @id             highlight-portals-my-level
// @namespace      https://github.com/IITC-CE/ingress-intel-total-conversion
// @updateURL      https://iitc.app/build/artifact/PR965/plugins/highlight-portals-my-level.meta.js
// @downloadURL    https://iitc.app/build/artifact/PR965/plugins/highlight-portals-my-level.user.js
// @match          https://intel.ingress.com/*
// @match          https://intel-x.ingress.com/*
// @icon           https://iitc.app/extras/plugin-icons/highlight-portals-my-level.svg
// @grant          none
// ==/UserScript==
