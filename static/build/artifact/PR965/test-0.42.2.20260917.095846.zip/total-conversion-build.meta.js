// ==UserScript==
// @author         jonatkins
// @name           IITC: Ingress intel map total conversion
// @version        0.42.2.20260917.095846
// @description    Total conversion for the ingress intel map.
// @run-at         document-end
// @id             total-conversion-build
// @namespace      https://github.com/IITC-CE/ingress-intel-total-conversion
// @updateURL      https://iitc.app/build/artifact/PR965/total-conversion-build.meta.js
// @downloadURL    https://iitc.app/build/artifact/PR965/total-conversion-build.user.js
// @match          https://intel.ingress.com/*
// @match          https://intel-x.ingress.com/*
// @icon           https://iitc.app/extras/plugin-icons/total-conversion-build.svg
// @grant          none
// ==/UserScript==
