// ==UserScript==
// @author         jonatkins
// @name           IITC plugin: Disable mouse wheel zoom
// @category       Tweaks
// @version        0.1.3.20261009.172300
// @description    Disable the use of mouse wheel to zoom. The map zoom controls or keyboard are still available.
// @id             scroll-wheel-zoom-disable
// @namespace      https://github.com/IITC-CE/ingress-intel-total-conversion
// @updateURL      https://iitc.app/build/artifact/PR975/plugins/scroll-wheel-zoom-disable.meta.js
// @downloadURL    https://iitc.app/build/artifact/PR975/plugins/scroll-wheel-zoom-disable.user.js
// @match          https://intel.ingress.com/*
// @match          https://intel-x.ingress.com/*
// @icon           https://iitc.app/extras/plugin-icons/scroll-wheel-zoom-disable.svg
// @grant          none
// ==/UserScript==
