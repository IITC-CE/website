// ==UserScript==
// @author         Hollow011
// @name           IITC plugin: Available AP statistics
// @category       Info
// @version        0.4.6.20261016.152022
// @description    Displays the per-team AP gains available in the current view.
// @id             ap-stats
// @namespace      https://github.com/IITC-CE/ingress-intel-total-conversion
// @updateURL      https://iitc.app/build/artifact/PR982/plugins/ap-stats.meta.js
// @downloadURL    https://iitc.app/build/artifact/PR982/plugins/ap-stats.user.js
// @match          https://intel.ingress.com/*
// @match          https://intel-x.ingress.com/*
// @icon           https://iitc.app/extras/plugin-icons/ap-stats.svg
// @grant          none
// ==/UserScript==
