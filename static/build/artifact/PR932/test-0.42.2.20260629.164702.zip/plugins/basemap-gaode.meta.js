// ==UserScript==
// @author         johnd0e
// @name           IITC plugin: Gaode (高德地图) / AutoNavi map
// @category       Map Tiles
// @version        0.1.5.20260629.164702
// @description    Map layers from AutoNavi / Gaode (高德地图)
// @id             basemap-gaode
// @namespace      https://github.com/IITC-CE/ingress-intel-total-conversion
// @updateURL      https://iitc.app/build/artifact/PR932/plugins/basemap-gaode.meta.js
// @downloadURL    https://iitc.app/build/artifact/PR932/plugins/basemap-gaode.user.js
// @match          https://intel.ingress.com/*
// @match          https://intel-x.ingress.com/*
// @icon           https://iitc.app/extras/plugin-icons/basemap-gaode.svg
// @grant          none
// ==/UserScript==
