// ==UserScript==
// @author         johtata
// @name           IITC plugin: Ornament icons basic
// @category       Layer
// @version        0.1.3.20260518.074702
// @description    Add own icons and names for ornaments
// @id             ornament-icons
// @namespace      https://github.com/IITC-CE/ingress-intel-total-conversion
// @updateURL      https://iitc.app/build/artifact/PR919/plugins/ornament-icons.meta.js
// @downloadURL    https://iitc.app/build/artifact/PR919/plugins/ornament-icons.user.js
// @match          https://intel.ingress.com/*
// @match          https://intel-x.ingress.com/*
// @icon           https://iitc.app/extras/plugin-icons/ornament-icons.svg
// @grant          none
// ==/UserScript==
