// ==UserScript==
// @author         jonatkins
// @name           IITC plugin: Ingress scoring regions
// @category       Layer
// @version        0.3.5.20261107.142628
// @description    Show the regional scoring cells grid on the map
// @id             regions
// @namespace      https://github.com/IITC-CE/ingress-intel-total-conversion
// @updateURL      https://iitc.app/build/artifact/PR980/plugins/regions.meta.js
// @downloadURL    https://iitc.app/build/artifact/PR980/plugins/regions.user.js
// @match          https://intel.ingress.com/*
// @match          https://intel-x.ingress.com/*
// @icon           https://iitc.app/extras/plugin-icons/regions.svg
// @grant          none
// ==/UserScript==
