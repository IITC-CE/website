// ==UserScript==
// @author         jonatkins
// @name           IITC plugin: Distance to portal
// @category       Portal Info
// @version        0.2.4.20261107.142628
// @description    Allows your current location to be set manually, then shows the distance to the selected portal. Useful when managing portal keys.
// @id             distance-to-portal
// @namespace      https://github.com/IITC-CE/ingress-intel-total-conversion
// @updateURL      https://iitc.app/build/artifact/PR980/plugins/distance-to-portal.meta.js
// @downloadURL    https://iitc.app/build/artifact/PR980/plugins/distance-to-portal.user.js
// @match          https://intel.ingress.com/*
// @match          https://intel-x.ingress.com/*
// @icon           https://iitc.app/extras/plugin-icons/distance-to-portal.svg
// @grant          none
// ==/UserScript==
