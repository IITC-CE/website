// ==UserScript==
// @author         ZasoGD
// @name           IITC plugin: Bookmarks for maps and portals
// @category       Controls
// @version        0.4.6.20260222.001838
// @description    Save your favorite Maps and Portals and move the intel map with a click. Works with sync. Supports Multi-Project-Extension
// @id             bookmarks
// @namespace      https://github.com/IITC-CE/ingress-intel-total-conversion
// @updateURL      https://iitc.app/build/artifact/PR882/plugins/bookmarks.meta.js
// @downloadURL    https://iitc.app/build/artifact/PR882/plugins/bookmarks.user.js
// @match          https://intel.ingress.com/*
// @match          https://intel-x.ingress.com/*
// @icon           https://iitc.app/extras/plugin-icons/bookmarks.svg
// @grant          none
// ==/UserScript==
