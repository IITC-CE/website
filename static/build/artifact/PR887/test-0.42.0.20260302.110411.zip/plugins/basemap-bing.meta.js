// ==UserScript==
// @author         johnd0e
// @name           IITC plugin: Bing maps
// @category       Map Tiles
// @version        0.3.4.20260302.110411
// @description    Add the bing.com map layers.
// @id             basemap-bing
// @namespace      https://github.com/IITC-CE/ingress-intel-total-conversion
// @updateURL      https://iitc.app/build/artifact/PR887/plugins/basemap-bing.meta.js
// @downloadURL    https://iitc.app/build/artifact/PR887/plugins/basemap-bing.user.js
// @match          https://intel.ingress.com/*
// @match          https://intel-x.ingress.com/*
// @icon           https://iitc.app/extras/plugin-icons/basemap-bing.svg
// @grant          none
// ==/UserScript==
