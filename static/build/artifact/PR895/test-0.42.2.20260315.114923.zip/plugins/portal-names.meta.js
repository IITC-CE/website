// ==UserScript==
// @author         ZasoGD
// @name           IITC plugin: Portal Names
// @category       Layer
// @version        0.2.5.20260315.114923
// @description    Show portal names on the map.
// @id             portal-names
// @namespace      https://github.com/IITC-CE/ingress-intel-total-conversion
// @updateURL      https://iitc.app/build/artifact/PR895/plugins/portal-names.meta.js
// @downloadURL    https://iitc.app/build/artifact/PR895/plugins/portal-names.user.js
// @match          https://intel.ingress.com/*
// @match          https://intel-x.ingress.com/*
// @icon           https://iitc.app/extras/plugin-icons/portal-names.svg
// @grant          none
// ==/UserScript==
