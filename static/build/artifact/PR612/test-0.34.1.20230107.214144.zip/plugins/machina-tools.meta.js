// ==UserScript==
// @name           IITC plugin: Machina Tools
// @author         Perringaiden
// @category       Misc
// @version        0.7.0.20230107.214144
// @description    Machina investigation tools
// @id             machina-tools
// @namespace      https://github.com/IITC-CE/ingress-intel-total-conversion
// @updateURL      https://iitc.app/build/artifact/PR612/plugins/machina-tools.meta.js
// @downloadURL    https://iitc.app/build/artifact/PR612/plugins/machina-tools.user.js
// @match          https://intel.ingress.com/*
// @match          https://intel-x.ingress.com/*
// @grant          none
// ==/UserScript==
