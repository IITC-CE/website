// ==UserScript==
// @author         ZasoGD
// @name           IITC plugin: Zaprange
// @category       Layer
// @version        0.1.9.20260708.223142
// @description    Shows the maximum range of attack by the portals.
// @id             zaprange
// @namespace      https://github.com/IITC-CE/ingress-intel-total-conversion
// @updateURL      https://iitc.app/build/artifact/PR934/plugins/zaprange.meta.js
// @downloadURL    https://iitc.app/build/artifact/PR934/plugins/zaprange.user.js
// @match          https://intel.ingress.com/*
// @match          https://intel-x.ingress.com/*
// @icon           https://iitc.app/extras/plugin-icons/zaprange.svg
// @grant          none
// ==/UserScript==
