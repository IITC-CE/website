// ==UserScript==
// @author         breunigs
// @name           IITC plugin: Scale bar
// @category       Controls
// @version        0.1.4.20261024.151739
// @description    Show scale bar on the map.
// @id             scale-bar
// @namespace      https://github.com/IITC-CE/ingress-intel-total-conversion
// @updateURL      https://iitc.app/build/artifact/PR985/plugins/scale-bar.meta.js
// @downloadURL    https://iitc.app/build/artifact/PR985/plugins/scale-bar.user.js
// @match          https://intel.ingress.com/*
// @match          https://intel-x.ingress.com/*
// @icon           https://iitc.app/extras/plugin-icons/scale-bar.svg
// @grant          none
// ==/UserScript==
