// ==UserScript==
// @author         johnd0e
// @name           IITC plugin: Mini map
// @category       Controls
// @version        0.4.5.20260423.120705
// @description    Show a mini map on the corner of the map.
// @id             minimap
// @namespace      https://github.com/IITC-CE/ingress-intel-total-conversion
// @updateURL      https://iitc.app/build/artifact/PR904/plugins/minimap.meta.js
// @downloadURL    https://iitc.app/build/artifact/PR904/plugins/minimap.user.js
// @match          https://intel.ingress.com/*
// @match          https://intel-x.ingress.com/*
// @icon           https://iitc.app/extras/plugin-icons/minimap.svg
// @grant          none
// ==/UserScript==
