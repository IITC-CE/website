// ==UserScript==
// @author         johnd0e
// @name           IITC plugin: Hide portal levels
// @category       Layer
// @version        0.1.4.20260614.103051
// @description    Replace all levels with single layerChooser's entry; reverting on longclick
// @id             hide-portal-levels
// @namespace      https://github.com/IITC-CE/ingress-intel-total-conversion
// @updateURL      https://iitc.app/build/artifact/PR922/plugins/hide-portal-levels.meta.js
// @downloadURL    https://iitc.app/build/artifact/PR922/plugins/hide-portal-levels.user.js
// @match          https://intel.ingress.com/*
// @match          https://intel-x.ingress.com/*
// @icon           https://iitc.app/extras/plugin-icons/hide-portal-levels.svg
// @grant          none
// ==/UserScript==
