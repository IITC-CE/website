// ==UserScript==
// @author         yenky
// @name           IITC plugin: Portal count
// @category       Info
// @version        0.2.7.20261110.124745
// @description    Display a list of all localized portals by level and faction.
// @id             portal-counts
// @namespace      https://github.com/IITC-CE/ingress-intel-total-conversion
// @updateURL      https://iitc.app/build/artifact/PR998/plugins/portal-counts.meta.js
// @downloadURL    https://iitc.app/build/artifact/PR998/plugins/portal-counts.user.js
// @match          https://intel.ingress.com/*
// @match          https://intel-x.ingress.com/*
// @icon           https://iitc.app/extras/plugin-icons/portal-counts.svg
// @grant          none
// ==/UserScript==
