// ==UserScript==
// @author         Costaspap
// @name           IITC plugin: Localized scoreboard
// @version        0.4.1.20261015.153031
// @category       Info
// @description    Display a scoreboard about all visible portals with statistics about both teams,like average portal level,link & field counts etc.
// @id             scoreboard
// @namespace      https://github.com/IITC-CE/ingress-intel-total-conversion
// @updateURL      https://iitc.app/build/artifact/PR981/plugins/scoreboard.meta.js
// @downloadURL    https://iitc.app/build/artifact/PR981/plugins/scoreboard.user.js
// @match          https://intel.ingress.com/*
// @match          https://intel-x.ingress.com/*
// @icon           https://iitc.app/extras/plugin-icons/scoreboard.svg
// @grant          none
// ==/UserScript==
