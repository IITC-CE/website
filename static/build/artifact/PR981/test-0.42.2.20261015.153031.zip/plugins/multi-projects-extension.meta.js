// ==UserScript==
// @author         ZasoGD
// @name           IITC plugin: Multi Projects Extension
// @category       Controls
// @version        0.1.5.20261015.153031
// @description    Create separated projects in some plugins.
// @id             multi-projects-extension
// @namespace      https://github.com/IITC-CE/ingress-intel-total-conversion
// @updateURL      https://iitc.app/build/artifact/PR981/plugins/multi-projects-extension.meta.js
// @downloadURL    https://iitc.app/build/artifact/PR981/plugins/multi-projects-extension.user.js
// @match          https://intel.ingress.com/*
// @match          https://intel-x.ingress.com/*
// @icon           https://iitc.app/extras/plugin-icons/multi-projects-extension.svg
// @grant          none
// ==/UserScript==
