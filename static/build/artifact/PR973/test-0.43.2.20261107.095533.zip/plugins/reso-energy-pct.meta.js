// ==UserScript==
// @author         xelio
// @name           IITC plugin: Reso energy % in portal details
// @category       Portal Info
// @version        0.1.5.20261107.095533
// @description    Show resonator energy percentage on resonator energy bar in portal details panel.
// @id             reso-energy-pct
// @namespace      https://github.com/IITC-CE/ingress-intel-total-conversion
// @updateURL      https://iitc.app/build/artifact/PR973/plugins/reso-energy-pct.meta.js
// @downloadURL    https://iitc.app/build/artifact/PR973/plugins/reso-energy-pct.user.js
// @match          https://intel.ingress.com/*
// @match          https://intel-x.ingress.com/*
// @icon           https://iitc.app/extras/plugin-icons/reso-energy-pct.svg
// @grant          none
// ==/UserScript==
