// ==UserScript==
// @author         fragger
// @name           IITC plugin: Pan control
// @category       Controls
// @version        0.2.5.20261107.095533
// @description    Show a panning control on the map.
// @id             pan-control
// @namespace      https://github.com/IITC-CE/ingress-intel-total-conversion
// @updateURL      https://iitc.app/build/artifact/PR973/plugins/pan-control.meta.js
// @downloadURL    https://iitc.app/build/artifact/PR973/plugins/pan-control.user.js
// @match          https://intel.ingress.com/*
// @match          https://intel-x.ingress.com/*
// @icon           https://iitc.app/extras/plugin-icons/pan-control.svg
// @grant          none
// ==/UserScript==
