// ==UserScript==
// @name           IITC plugin: Machina tracker
// @author         McBen
// @category       Layer
// @version        1.1.2.20260906.134343
// @description    Show locations of Machina activities
// @id             machina-tracker
// @namespace      https://github.com/IITC-CE/ingress-intel-total-conversion
// @updateURL      https://iitc.app/build/artifact/PR917/plugins/machina-tracker.meta.js
// @downloadURL    https://iitc.app/build/artifact/PR917/plugins/machina-tracker.user.js
// @match          https://intel.ingress.com/*
// @match          https://intel-x.ingress.com/*
// @icon           https://iitc.app/extras/plugin-icons/machina-tracker.svg
// @grant          none
// ==/UserScript==
