// ==UserScript==
// @author         ZasoGD
// @name           IITC plugin: Multi Projects Extension
// @category       Control
// @version        0.0.7.20210315.081859
// @description    Create separated projects in some plugins.
// @id             multi-projects-extension
// @namespace      https://github.com/IITC-CE/ingress-intel-total-conversion
// @updateURL      https://iitc.modos189.ru/build/beta/plugins/multi-projects-extension.meta.js
// @downloadURL    https://iitc.modos189.ru/build/beta/plugins/multi-projects-extension.user.js
// @match          https://intel.ingress.com/*
// @grant          none
// ==/UserScript==
