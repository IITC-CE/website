// ==UserScript==
// @author         jaiperdu
// @name           IITC plugin: Debug console tab
// @category       Debug
// @version        0.1.0.20220726.151245
// @description    Add a debug console tab
// @id             debug-console
// @namespace      https://github.com/IITC-CE/ingress-intel-total-conversion
// @updateURL      https://iitc.app/build/beta/plugins/debug-console.meta.js
// @downloadURL    https://iitc.app/build/beta/plugins/debug-console.user.js
// @match          https://intel.ingress.com/*
// @grant          none
// ==/UserScript==
