// ==UserScript==
// @author         johnd0e
// @name           IITC plugin: Kartverket.no maps (Norway)
// @category       Map Tiles
// @version        0.3.2.20261109.131557
// @description    Add Kartverket.no map layers.
// @id             basemap-kartverket
// @namespace      https://github.com/IITC-CE/ingress-intel-total-conversion
// @updateURL      https://iitc.app/build/beta/plugins/basemap-kartverket.meta.js
// @downloadURL    https://iitc.app/build/beta/plugins/basemap-kartverket.user.js
// @match          https://intel.ingress.com/*
// @match          https://intel-x.ingress.com/*
// @icon           https://iitc.app/extras/plugin-icons/basemap-kartverket.svg
// @grant          none
// ==/UserScript==
