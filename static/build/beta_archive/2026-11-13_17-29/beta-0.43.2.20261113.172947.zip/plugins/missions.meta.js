// ==UserScript==
// @author         jonatkins
// @name           IITC plugin: Missions
// @category       Info
// @version        0.4.0.20261113.172947
// @description    View missions. Marking progress on waypoints/missions basis. Showing mission paths on the map.
// @id             missions
// @namespace      https://github.com/IITC-CE/ingress-intel-total-conversion
// @updateURL      https://iitc.app/build/beta/plugins/missions.meta.js
// @downloadURL    https://iitc.app/build/beta/plugins/missions.user.js
// @match          https://intel.ingress.com/*
// @match          https://intel-x.ingress.com/*
// @icon           https://iitc.app/extras/plugin-icons/missions.svg
// @grant          none
// ==/UserScript==
