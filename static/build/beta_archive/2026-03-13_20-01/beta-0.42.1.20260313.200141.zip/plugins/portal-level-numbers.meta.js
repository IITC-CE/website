// ==UserScript==
// @author         rongou
// @name           IITC plugin: Portal Level Numbers
// @category       Layer
// @version        0.2.5.20260313.200141
// @description    Show portal level numbers on map.
// @id             portal-level-numbers
// @namespace      https://github.com/IITC-CE/ingress-intel-total-conversion
// @updateURL      https://iitc.app/build/beta/plugins/portal-level-numbers.meta.js
// @downloadURL    https://iitc.app/build/beta/plugins/portal-level-numbers.user.js
// @match          https://intel.ingress.com/*
// @match          https://intel-x.ingress.com/*
// @icon           https://iitc.app/extras/plugin-icons/portal-level-numbers.svg
// @grant          none
// ==/UserScript==
