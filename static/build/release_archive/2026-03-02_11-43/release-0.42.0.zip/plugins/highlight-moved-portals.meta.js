// ==UserScript==
// @author         screach
// @name           IITC plugin: Highlight moved portals
// @category       Highlighter
// @version        0.1.2
// @description    Highlights portals with links with different location data
// @id             highlight-moved-portals
// @namespace      https://github.com/IITC-CE/ingress-intel-total-conversion
// @updateURL      https://iitc.app/build/release/plugins/highlight-moved-portals.meta.js
// @downloadURL    https://iitc.app/build/release/plugins/highlight-moved-portals.user.js
// @match          https://intel.ingress.com/*
// @match          https://intel-x.ingress.com/*
// @icon           https://iitc.app/extras/plugin-icons/highlight-moved-portals.svg
// @grant          none
// ==/UserScript==
