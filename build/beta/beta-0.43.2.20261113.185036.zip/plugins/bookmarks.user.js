// ==UserScript==
// @author         ZasoGD
// @name           IITC plugin: Bookmarks for maps and portals
// @category       Controls
// @version        0.5.0.20261113.185036
// @description    Save your favorite Maps and Portals and move the intel map with a click. Works with sync. Supports Multi-Project-Extension
// @id             bookmarks
// @namespace      https://github.com/IITC-CE/ingress-intel-total-conversion
// @updateURL      https://iitc.app/build/beta/plugins/bookmarks.meta.js
// @downloadURL    https://iitc.app/build/beta/plugins/bookmarks.user.js
// @match          https://intel.ingress.com/*
// @match          https://intel-x.ingress.com/*
// @icon           https://iitc.app/extras/plugin-icons/bookmarks.svg
// @grant          none
// ==/UserScript==

function wrapper(plugin_info) {
// ensure plugin framework is there, even if iitc is not yet loaded
if(typeof window.plugin !== 'function') window.plugin = function() {};

//PLUGIN AUTHORS: writing a plugin outside of the IITC build environment? if so, delete these lines!!
//(leaving them in place might break the 'About IITC' page or break update checks)
plugin_info.buildName = 'beta';
plugin_info.dateTimeVersion = '2026-11-13-185036';
plugin_info.pluginId = 'bookmarks';
//END PLUGIN AUTHORS NOTE

/* exported setup, changelog --eslint */
/* global IITC, L -- eslint */

var changelog = [
  {
    version: '0.5.0',
    changes: [
      'Register with the Sync plugin regardless of plugin load order',
      'Sync every Multi Projects Extension project, not just the default one',
      'Let deleted projects propagate through sync',
      'Draw icons from the bundled font',
    ],
  },
  { version: '0.4.7', changes: ['Fix data reset issue'] },
  {
    version: '0.4.6',
    changes: ['Refactoring: fix eslint'],
  },
  {
    version: '0.4.5',
    changes: ['Simplying API for adding a new portal', 'Version upgrade due to a change in the wrapper: plugin icons are now vectorized'],
  },
  {
    version: '0.4.4',
    changes: ['IITC.toolbox API is used to create plugin buttons'],
  },
  {
    version: '0.4.3',
    changes: ['Extracted "formatDistance" function for global use'],
  },
];

/* **********************************************************************

  HOOKS:
  - pluginBkmrksEdit: fired when a bookmarks/folder is removed, added or sorted, also when a folder is opened/closed;
  - pluginBkmrksSyncEnd: fired when the sync is finished;

********************************************************************** */

// use own namespace for plugin
window.plugin.bookmarks = function () {};

window.plugin.bookmarks.SYNC_DELAY = 5000;

window.plugin.bookmarks.KEY_OTHER_BKMRK = 'idOthers';
window.plugin.bookmarks.KEY_STORAGE = 'plugin-bookmarks';
// MPE points KEY_STORAGE at the selected project, so the default one is kept separately
window.plugin.bookmarks.DEFAULT_KEY_STORAGE = 'plugin-bookmarks';
window.plugin.bookmarks.KEY_STATUS_BOX = 'plugin-bookmarks-box';

window.plugin.bookmarks.UPDATE_QUEUE = { key: 'plugin-bookmarks-queue', field: 'updateQueue' };
window.plugin.bookmarks.UPDATING_QUEUE = { key: 'plugin-bookmarks-updating-queue', field: 'updatingQueue' };

// bookmarks of the selected project, what the rest of the plugin reads
window.plugin.bookmarks.currentProject = {};
// every project's bookmarks, the map handed to sync: the name is also the Drive file name
window.plugin.bookmarks.SYNC_FIELD = 'bkmrksObj';
window.plugin.bookmarks.SYNC_KEY_DELIMITER = '|';
// deletion leaves this mark, so a device that still has the project drops it instead of pushing it back
window.plugin.bookmarks.DELETED_MARK = 'deleted';
// how long a mark is kept: long enough for every device to have synced at least once
window.plugin.bookmarks.DELETED_MARK_TTL = 30 * 24 * 60 * 60 * 1000;
window.plugin.bookmarks.bkmrksObj = {};
window.plugin.bookmarks.LIST_TYPES = ['portals', 'maps'];
window.plugin.bookmarks.emptyList = () => ({ [window.plugin.bookmarks.KEY_OTHER_BKMRK]: { label: 'Others', state: 1, bkmrk: {} } });
window.plugin.bookmarks.statusBox = {};
window.plugin.bookmarks.updateQueue = {};
window.plugin.bookmarks.updatingQueue = {};

window.plugin.bookmarks.IDcount = 0;

window.plugin.bookmarks.enableSync = false;

window.plugin.bookmarks.starLayers = {};
window.plugin.bookmarks.starLayerGroup = null;

window.plugin.bookmarks.isSmart = undefined;

/** *******************************************************************************************************************/

// Generate an ID for the bookmark (date time + random number)
window.plugin.bookmarks.generateID = function () {
  var d = new Date();
  var ID = d.getTime().toString() + window.plugin.bookmarks.IDcount.toString() + (Math.floor(Math.random() * 99) + 1);
  window.plugin.bookmarks.IDcount++;
  ID = 'id' + ID.toString();
  return ID;
};

// Format the string
window.plugin.bookmarks.escapeHtml = function (text) {
  return text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;')
    .replace(/\//g, '&#47;')
    .replace(/\\/g, '&#92;');
};

// the text escapeHtml was given, for labels shown as text rather than as HTML
window.plugin.bookmarks.unescapeHtml = (html) =>
  html
    .replace(/&#92;/g, '\\')
    .replace(/&#47;/g, '/')
    .replace(/&#039;/g, "'")
    .replace(/&quot;/g, '"')
    .replace(/&gt;/g, '>')
    .replace(/&lt;/g, '<')
    .replace(/&amp;/g, '&');

window.plugin.bookmarks.escapeUnicode = function (str) {
  for (var result = '', index = 0, charCode; !isNaN((charCode = str.charCodeAt(index))); ) {
    if ((charCode & 127) === charCode) {
      result += str[index];
    } else {
      result += '\\u' + ('0000' + charCode.toString(16)).slice(-4);
    }
    index++;
  }
  return result;
};

// Update the localStorage
window.plugin.bookmarks.saveStorage = function () {
  localStorage[window.plugin.bookmarks.KEY_STORAGE] = JSON.stringify(window.plugin.bookmarks.currentProject);
  // the options page lists the folders
  IITC.options.refresh('bookmarks');
};

// Load the localStorage
window.plugin.bookmarks.loadStorage = function () {
  window.plugin.bookmarks.currentProject = JSON.parse(localStorage[window.plugin.bookmarks.KEY_STORAGE]);
};

window.plugin.bookmarks.saveStorageBox = function () {
  localStorage[window.plugin.bookmarks.KEY_STATUS_BOX] = JSON.stringify(window.plugin.bookmarks.statusBox);
};

window.plugin.bookmarks.loadStorageBox = function () {
  window.plugin.bookmarks.statusBox = JSON.parse(localStorage[window.plugin.bookmarks.KEY_STATUS_BOX]);
};

window.plugin.bookmarks.upgradeToNewStorage = function () {
  if (localStorage['plugin-bookmarks-portals-data'] && localStorage['plugin-bookmarks-maps-data']) {
    var oldStor_1 = JSON.parse(localStorage['plugin-bookmarks-maps-data']);
    var oldStor_2 = JSON.parse(localStorage['plugin-bookmarks-portals-data']);

    window.plugin.bookmarks.currentProject = {};
    window.plugin.bookmarks.currentProject.maps = oldStor_1.bkmrk_maps;
    window.plugin.bookmarks.currentProject.portals = oldStor_2.bkmrk_portals;
    window.plugin.bookmarks.saveStorage();

    localStorage.removeItem('plugin-bookmarks-maps-data');
    localStorage.removeItem('plugin-bookmarks-portals-data');
    localStorage.removeItem('plugin-bookmarks-status-box');
  }
};

window.plugin.bookmarks.createStorage = function () {
  if (!localStorage[window.plugin.bookmarks.KEY_STORAGE]) {
    window.plugin.bookmarks.currentProject = {};
    window.plugin.bookmarks.currentProject.maps = { idOthers: { label: 'Others', state: 1, bkmrk: {} } };
    window.plugin.bookmarks.currentProject.portals = { idOthers: { label: 'Others', state: 1, bkmrk: {} } };
    window.plugin.bookmarks.saveStorage();
  }
  if (!localStorage[window.plugin.bookmarks.KEY_STATUS_BOX]) {
    window.plugin.bookmarks.statusBox = {};
    window.plugin.bookmarks.statusBox.show = 1;
    window.plugin.bookmarks.statusBox.page = 0;
    window.plugin.bookmarks.statusBox.pos = { x: 100, y: 100 };
    window.plugin.bookmarks.saveStorageBox();
  }
};

window.plugin.bookmarks.refreshBkmrks = function () {
  $('#bkmrk_maps > ul, #bkmrk_portals > ul').remove();

  window.plugin.bookmarks.loadStorage();
  window.plugin.bookmarks.loadList('maps');
  window.plugin.bookmarks.loadList('portals');

  window.plugin.bookmarks.updateStarPortal();
  window.plugin.bookmarks.jquerySortableScript();
  // the options page lists the folders
  IITC.options.refresh('bookmarks');
};

/** *************************************************************************************************************************************************************/

// Show/hide the bookmarks box
window.plugin.bookmarks.switchStatusBkmrksBox = function (status) {
  var newStatus = status;

  if (newStatus === 'switch') {
    if (window.plugin.bookmarks.statusBox.show === 1) {
      newStatus = 0;
    } else {
      newStatus = 1;
    }
  }

  $('#bookmarksBox').css('height', newStatus === 1 ? 'auto' : '0');
  window.plugin.bookmarks.updateBoxButton(newStatus === 1);

  window.plugin.bookmarks.statusBox['show'] = newStatus;
  window.plugin.bookmarks.saveStorageBox();
};

window.plugin.bookmarks.addBoxButton = function () {
  const BoxButton = L.Control.extend({
    options: { position: 'topright' },
    onAdd: () => {
      const container = L.DomUtil.create('div', 'iitc-control-button iitc-bookmarks-button');
      const button = L.DomUtil.create('a', '', container);
      button.href = '#';
      button.title = 'Show the bookmarks [v]';
      button.setAttribute('role', 'button');
      button.setAttribute('aria-label', 'Bookmarks');
      const icon = L.DomUtil.create('iitc-icon', '', button);
      icon.setAttribute('fallback', '★');
      icon.textContent = 'bookmark';
      L.DomEvent.on(button, 'click', (event) => {
        L.DomEvent.preventDefault(event);
        window.plugin.bookmarks.switchStatusBkmrksBox(1);
      });
      L.DomEvent.disableClickPropagation(container);
      window.plugin.bookmarks.boxButton = container;
      window.plugin.bookmarks.updateBoxButton(window.plugin.bookmarks.statusBox.show === 1);
      return container;
    },
  });
  new BoxButton().addTo(window.map);
};

// A hidden link ignores its access key, so the minimize button holds it while the box is open
window.plugin.bookmarks.updateBoxButton = function (boxShown) {
  const container = window.plugin.bookmarks.boxButton;
  if (!container) return;
  container.style.display = boxShown ? 'none' : '';
  container.querySelector('a').accessKey = boxShown ? '' : 'v';
  const minimize = document.getElementById('bookmarksMin');
  if (minimize) {
    minimize.accessKey = boxShown ? 'v' : '';
    minimize.title = 'Minimize [v]';
  }
};

window.plugin.bookmarks.onPaneChanged = function (pane) {
  if (pane === 'plugin-bookmarks') $('#bookmarksBox').css('display', '');
  else $('#bookmarksBox').css('display', 'none');
};

// Switch list (maps/portals)
window.plugin.bookmarks.switchPageBkmrksBox = function (elem, page) {
  window.plugin.bookmarks.statusBox.page = page;
  window.plugin.bookmarks.saveStorageBox();

  $('h5').removeClass('current');
  $(elem).addClass('current');

  var sectList = '#' + $(elem).attr('class').replace(' current', '');
  $('#bookmarksBox .bookmarkList').removeClass('current');
  $(sectList).addClass('current');
};

// Switch the status folder to open/close (in the localStorage)
window.plugin.bookmarks.openFolder = function (elem) {
  $(elem).parent().parent('li').toggleClass('open');

  var typeList = $(elem).parent().parent().parent().parent('div').attr('id').replace('bkmrk_', '');
  var ID = $(elem).parent().parent('li').attr('id');

  var newFlag;
  var flag = window.plugin.bookmarks.currentProject[typeList][ID]['state'];
  if (flag) {
    newFlag = 0;
  } else if (!flag) {
    newFlag = 1;
  }

  window.plugin.bookmarks.currentProject[typeList][ID]['state'] = newFlag;
  window.plugin.bookmarks.saveStorage();
  window.runHooks('pluginBkmrksEdit', { target: 'folder', action: newFlag ? 'open' : 'close', id: ID });
};

// Load the HTML bookmarks
window.plugin.bookmarks.loadList = function (typeList) {
  var element = '';
  var elementTemp = '';
  var elementExc = '';
  var returnToMap = '';

  if (window.plugin.bookmarks.isSmart) {
    returnToMap = "window.show('map');";
  }

  // For each folder
  var list = window.plugin.bookmarks.currentProject[typeList];

  for (var idFolders in list) {
    var folders = list[idFolders];
    var active = '';

    // Create a label and a anchor for the sortable
    var folderDelete =
      '<span class="folderLabel"><a class="bookmarksRemoveFrom" onclick="window.plugin.bookmarks.removeElement(this, \'folder\');return false;" title="Remove this folder"><iitc-icon fallback="X">close</iitc-icon></a>';
    var folderName =
      '<a class="bookmarksAnchor" onclick="window.plugin.bookmarks.openFolder(this);return false"><span></span>' + folders['label'] + '</a></span>'; // <span><span></span></span>';
    var folderLabel = folderDelete + folderName;

    if (folders['state']) {
      active = ' open';
    }
    if (idFolders === window.plugin.bookmarks.KEY_OTHER_BKMRK) {
      folderLabel = '';
      active = ' othersBookmarks open';
    }
    // Create a folder
    elementTemp = `<li class="bookmarkFolder${active}" id="${idFolders}">${folderLabel}<ul>`;

    // For each bookmark
    var fold = folders['bkmrk'];
    for (var idBkmrk in fold) {
      var btn_link;
      var btn_remove = `<a class="bookmarksRemoveFrom" onclick="window.plugin.bookmarks.removeElement(this, '${typeList}');return false;" title="Remove from bookmarks"><iitc-icon fallback="X">close</iitc-icon></a>`;

      var btn_move = '';
      if (window.plugin.bookmarks.isSmart) {
        btn_move = `<a class="bookmarksMoveIn" onclick="window.plugin.bookmarks.dialogMobileSort('${typeList}', this);return false;">=</a>`;
      }

      var bkmrk = fold[idBkmrk];
      var label = bkmrk['label'];
      var latlng = bkmrk['latlng'];

      // If it's a map
      if (typeList === 'maps') {
        if (bkmrk['label'] === '') {
          label = bkmrk['latlng'] + ' [' + bkmrk['z'] + ']';
        }
        btn_link = `<a class="bookmarksLink" onclick="${returnToMap}window.map.setView([${latlng}], ${bkmrk['z']});return false;">${label}</a>`;
      }
      // If it's a portal
      else if (typeList === 'portals') {
        var guid = bkmrk['guid'];
        const bookmarks_onclick = `$('a.bookmarksLink.selected').removeClass('selected');${returnToMap}IITC.portal.zoomToAndShow('${guid}', [${latlng}]);return false;`;
        btn_link = `<a class="bookmarksLink" onclick="${bookmarks_onclick}">${label}</a>`;
      }
      // Create the bookmark
      elementTemp += '<li class="bkmrk" id="' + idBkmrk + '">' + btn_remove + btn_move + btn_link + '</li>';
    }
    elementTemp += '</li></ul>';

    // Add folder 'Others' in last position
    if (idFolders !== window.plugin.bookmarks.KEY_OTHER_BKMRK) {
      element += elementTemp;
    } else {
      elementExc = elementTemp;
    }
  }
  element += elementExc;
  element = '<ul>' + element + '</ul>';

  // Append all folders and bookmarks
  $('#bkmrk_' + typeList).append(element);
};

/** *************************************************************************************************************************************************************/

window.plugin.bookmarks.findByGuid = function (guid) {
  var list = window.plugin.bookmarks.currentProject['portals'];

  for (var idFolders in list) {
    for (var idBkmrk in list[idFolders]['bkmrk']) {
      var portalGuid = list[idFolders]['bkmrk'][idBkmrk]['guid'];
      if (guid === portalGuid) {
        return { id_folder: idFolders, id_bookmark: idBkmrk };
      }
    }
  }
};

// Append a 'star' flag in sidebar.
window.plugin.bookmarks.onPortalSelectedPending = false;
window.plugin.bookmarks.onPortalSelected = function () {
  $('.bkmrksStar').remove();

  if (window.selectedPortal === null) return;

  if (!window.plugin.bookmarks.onPortalSelectedPending) {
    window.plugin.bookmarks.onPortalSelectedPending = true;

    setTimeout(function () {
      // the sidebar is constructed after firing the hook
      window.plugin.bookmarks.onPortalSelectedPending = false;

      $('.bkmrksStar').remove();

      if (typeof Storage === 'undefined') {
        $('#portaldetails > .imgpreview').after(window.plugin.bookmarks.htmlDisabledMessage);
        return;
      }

      // Prepend a star to mobile status-bar
      if (window.plugin.bookmarks.isSmart) {
        $('#updatestatus').prepend(window.plugin.bookmarks.htmlStar);
        $('#updatestatus .bkmrksStar').attr('title', '');
      }

      $('#portaldetails > h3.title').prepend(window.plugin.bookmarks.htmlStar);
      window.plugin.bookmarks.updateStarPortal();
    }, 0);
  }
};

// Update the status of the star (when a portal is selected from the map/bookmarks-list)
window.plugin.bookmarks.updateStarPortal = function () {
  var guid = window.selectedPortal;
  $('.bkmrksStar').removeClass('favorite');
  $('.bkmrk a.bookmarksLink.selected').removeClass('selected');

  // If current portal is into bookmarks: select bookmark portal from portals list and select the star
  if (localStorage[window.plugin.bookmarks.KEY_STORAGE].search(guid) !== -1) {
    var bkmrkData = window.plugin.bookmarks.findByGuid(guid);
    if (bkmrkData) {
      $('.bkmrk#' + bkmrkData['id_bookmark'] + ' a.bookmarksLink').addClass('selected');
      $('.bkmrksStar').addClass('favorite');
    }
  }
};

// Switch the status of the star
window.plugin.bookmarks.switchStarPortal = function (guid) {
  if (guid === undefined) guid = window.selectedPortal;

  // If portal is saved in bookmarks: Remove this bookmark
  var bkmrkData = window.plugin.bookmarks.findByGuid(guid);
  if (bkmrkData) {
    var list = window.plugin.bookmarks.currentProject['portals'];
    delete list[bkmrkData['id_folder']]['bkmrk'][bkmrkData['id_bookmark']];
    $('.bkmrk#' + bkmrkData['id_bookmark'] + '').remove();

    window.plugin.bookmarks.saveStorage();
    window.plugin.bookmarks.updateStarPortal();

    window.runHooks('pluginBkmrksEdit', { target: 'portal', action: 'remove', folder: bkmrkData['id_folder'], id: bkmrkData['id_bookmark'], guid: guid });
    console.log('BOOKMARKS: removed portal (' + bkmrkData['id_bookmark'] + ' situated in ' + bkmrkData['id_folder'] + ' folder)');
  }
  // If portal isn't saved in bookmarks: Add this bookmark
  else {
    window.plugin.bookmarks.addPortalBookmarkByGuid(guid, true);
  }
};

/**
 * Adds a portal to the default bookmark folder.
 *
 * @param {L.circleMarker} marker - As enhanced when added to
 * window.portals.
 * @param {boolean} doPostProcess - Whether additional post-processing
 * should be done after the bookmark was added.  E.g., saving to local
 * storage, refreshing the widget, and running hooks.  If part of a batch
 * update, this should probably be false.
 */
window.plugin.bookmarks.addPortalBookmarkByMarker = function (marker, doPostProcess) {
  const guid = marker.options.guid;
  const label = marker.options.data.title;
  const ll = marker.getLatLng();
  const latlng = `${ll.lat},${ll.lng}`;
  const ID = window.plugin.bookmarks.generateID();

  window.plugin.bookmarks.currentProject['portals'][window.plugin.bookmarks.KEY_OTHER_BKMRK]['bkmrk'][ID] = {
    guid: guid,
    latlng: latlng,
    label: label,
  };

  if (doPostProcess) {
    window.plugin.bookmarks.saveStorage();
    window.plugin.bookmarks.refreshBkmrks();
    window.runHooks('pluginBkmrksEdit', {
      target: 'portal',
      action: 'add',
      id: ID,
      guid: guid,
    });
    console.log(`BOOKMARKS: added portal ${ID}`);
  }
};

/**
 * Adds a portal to the default bookmark folder.
 *
 * @param {string} guid - The GUID of the portal.
 * @param {boolean} doPostProcess - Whether additional post processing
 * should be done after the bookmark was added.  E.g., saving to local
 * storage, refreshing the widget, and running hooks.  If part of a batch
 * update, this should probably be false.
 * @throws {Error} - If guid does not exist in window.portals.
 */
window.plugin.bookmarks.addPortalBookmarkByGuid = function (guid, doPostProcess) {
  const marker = window.portals[guid];
  if (marker) {
    window.plugin.bookmarks.addPortalBookmarkByMarker(marker, doPostProcess);
  } else {
    throw new Error(`Could not find portal information for guid "${guid}"`);
  }
};

/**
 * Adds a portal to the default bookmark folder.
 *
 * The window.plugin.bookmarks.addPortalBookmarkBy{Guid,Marker}() functions
 * should be used for new code.
 *
 * @deprecated
 * @param {string} guid - The GUID of the portal.
 * @param {string} latlng - 'lat,lng' for the portal.
 * @param {string} label - The title of the portal.  Typically this is the
 * same value as the options.data.title property from the appropriate
 * window.portals entry, though nothing enforces this.
 */
window.plugin.bookmarks.addPortalBookmark = function (guid, latlng, label) {
  var ID = window.plugin.bookmarks.generateID();

  // Add bookmark in the localStorage
  window.plugin.bookmarks.currentProject['portals'][window.plugin.bookmarks.KEY_OTHER_BKMRK]['bkmrk'][ID] = { guid: guid, latlng: latlng, label: label };

  window.plugin.bookmarks.saveStorage();
  window.plugin.bookmarks.refreshBkmrks();
  window.runHooks('pluginBkmrksEdit', { target: 'portal', action: 'add', id: ID, guid: guid });
  console.log('BOOKMARKS: added portal ' + ID);
};

// Add BOOKMARK/FOLDER
window.plugin.bookmarks.addElement = function (elem, type) {
  var ID = window.plugin.bookmarks.generateID();
  var typeList = $(elem).parent().parent('div').attr('id');

  // Get the label | Convert some characters | Set the input (empty)
  var input = `#${typeList} .addForm input`;
  var label = $(input).val();
  label = window.plugin.bookmarks.escapeHtml(label);
  $(input).val('');

  // Add a map
  if (type === 'map') {
    // Get the coordinates and zoom
    var c = window.map.getCenter();
    var lat = Math.round(c.lat * 1e6) / 1e6;
    var lng = Math.round(c.lng * 1e6) / 1e6;
    var latlng = lat + ',' + lng;
    var zoom = parseInt(window.map.getZoom());
    // Add bookmark in the localStorage
    window.plugin.bookmarks.currentProject['maps'][window.plugin.bookmarks.KEY_OTHER_BKMRK]['bkmrk'][ID] = { label: label, latlng: latlng, z: zoom };
  } else {
    if (label === '') {
      label = 'Folder';
    }
    var short_type = typeList.replace('bkmrk_', '');
    // Add new folder in the localStorage
    window.plugin.bookmarks.currentProject[short_type][ID] = { label: label, state: 1, bkmrk: {} };
  }
  window.plugin.bookmarks.saveStorage();
  window.plugin.bookmarks.refreshBkmrks();
  window.runHooks('pluginBkmrksEdit', { target: type, action: 'add', id: ID });
  console.log('BOOKMARKS: added ' + type + ' ' + ID);
};

// Remove BOOKMARK/FOLDER
window.plugin.bookmarks.removeElement = function (elem, type) {
  if (type === 'maps' || type === 'portals') {
    const typeList = $(elem).parent().parent().parent().parent().parent('div').attr('id');
    const ID = $(elem).parent('li').attr('id');
    var IDfold = $(elem).parent().parent().parent('li').attr('id');
    var guid = window.plugin.bookmarks.currentProject[typeList.replace('bkmrk_', '')][IDfold]['bkmrk'][ID].guid;

    delete window.plugin.bookmarks.currentProject[typeList.replace('bkmrk_', '')][IDfold]['bkmrk'][ID];
    $(elem).parent('li').remove();

    if (type === 'portals') {
      window.plugin.bookmarks.updateStarPortal();
      window.plugin.bookmarks.saveStorage();

      window.runHooks('pluginBkmrksEdit', { target: 'portal', action: 'remove', folder: IDfold, id: ID, guid: guid });
      console.log('BOOKMARKS: removed portal (' + ID + ' situated in ' + IDfold + ' folder)');
    } else {
      window.plugin.bookmarks.saveStorage();
      window.runHooks('pluginBkmrksEdit', { target: 'map', action: 'remove', id: ID });
      console.log('BOOKMARKS: removed map ' + ID);
    }
  } else if (type === 'folder') {
    const typeList = $(elem).parent().parent().parent().parent('div').attr('id');
    const ID = $(elem).parent().parent('li').attr('id');

    delete window.plugin.bookmarks.currentProject[typeList.replace('bkmrk_', '')][ID];
    $(elem).parent().parent('li').remove();
    window.plugin.bookmarks.saveStorage();
    window.plugin.bookmarks.updateStarPortal();
    window.runHooks('pluginBkmrksEdit', { target: 'folder', action: 'remove', id: ID });
    console.log('BOOKMARKS: removed folder ' + ID);
  }
};

window.plugin.bookmarks.deleteMode = function () {
  $('#bookmarksBox').removeClass('moveMode').toggleClass('deleteMode');
};

window.plugin.bookmarks.moveMode = function () {
  $('#bookmarksBox').removeClass('deleteMode').toggleClass('moveMode');
};

window.plugin.bookmarks.mobileSortIDb = '';
window.plugin.bookmarks.mobileSortIDf = '';
window.plugin.bookmarks.dialogMobileSort = function (type, elem) {
  window.plugin.bookmarks.mobileSortIDb = $(elem).parent('li.bkmrk').attr('id');
  window.plugin.bookmarks.mobileSortIDf = $(elem).parent('li.bkmrk').parent('ul').parent('li.bookmarkFolder').attr('id');

  if (type === 'maps') {
    type = 1;
  } else if (type === 'portals') {
    type = 2;
  }

  window.dialog({
    html: window.plugin.bookmarks.dialogLoadListFolders('bookmarksDialogMobileSort', 'window.plugin.bookmarks.mobileSort', true, type),
    dialogClass: 'ui-dialog-bkmrksSet-copy',
    id: 'plugin-bookmarks-move-bookmark',
    title: 'Bookmarks - Move Bookmark',
  });
};

window.plugin.bookmarks.mobileSort = function (elem) {
  var type = $(elem).data('type');
  var idBkmrk = window.plugin.bookmarks.mobileSortIDb;
  var newFold = $(elem).data('id');
  var oldFold = window.plugin.bookmarks.mobileSortIDf;

  var Bkmrk = window.plugin.bookmarks.currentProject[type][oldFold].bkmrk[idBkmrk];

  delete window.plugin.bookmarks.currentProject[type][oldFold].bkmrk[idBkmrk];

  window.plugin.bookmarks.currentProject[type][newFold].bkmrk[idBkmrk] = Bkmrk;

  window.plugin.bookmarks.saveStorage();
  window.plugin.bookmarks.refreshBkmrks();
  window.runHooks('pluginBkmrksEdit', { target: 'bookmarks', action: 'sort' });
  window.plugin.bookmarks.mobileSortIDf = newFold;
  console.log(`Move Bookmarks ${type} ID:${idBkmrk} from folder ID:${oldFold} to folder ID:${newFold}`);
};

window.plugin.bookmarks.onSearch = function (query) {
  var term = query.term.toLowerCase();

  $.each(window.plugin.bookmarks.currentProject.maps, function (id, folder) {
    $.each(folder.bkmrk, function (id, bookmark) {
      if (bookmark.label.toLowerCase().indexOf(term) === -1) return;

      query.addResult({
        title: window.escapeHtmlSpecialChars(bookmark.label),
        description: `Map in folder "${window.escapeHtmlSpecialChars(folder.label)}"`,
        icon: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAwAAAAMCAYAAABWdVznAAAABHNCSVQICAgIfAhkiAAAAAlwSFlzAAAN1wAADdcBQiibeAAAABl0RVh0U29mdHdhcmUAd3d3Lmlua3NjYXBlLm9yZ5vuPBoAAADYSURBVCiRldExLoRxEAXw33xZ4QIKB9BQWPl0yFKJA4hCo1CqXMABVA6gcgkFnc7/s7VQaByAgoYdhU3sZr9NmGSaee/NvJeJUkr6R3WgrusYm/ajJ7zr5t3ouGmarFrXpFPpuA2aFDSxIWxjXz/mWy25jx3hEAsqS0NsFi/68YxHlXPK8MKbGwR6GN06g0XhwYrrX0tb+enJAS5b8pzp5gk5GM+wl1/C1YQgfEwPPbA+JN3iAgMsTxeEOWlXNzet5pHKGl7HOKWUzEx/6VJKdvj54IT3KfUNvrNZ/jYm+uoAAAAASUVORK5CYII=',
        position: new L.LatLng(...bookmark.latlng.split(',')),
        zoom: bookmark.z,
        onSelected: window.plugin.bookmarks.onSearchResultSelected,
      });
    });
  });

  $.each(window.plugin.bookmarks.currentProject.portals, function (id, folder) {
    $.each(folder.bkmrk, function (id, bookmark) {
      if (bookmark.label.toLowerCase().indexOf(term) === -1) return;

      query.addResult({
        title: window.escapeHtmlSpecialChars(bookmark.label),
        description: `Bookmark in folder "${window.escapeHtmlSpecialChars(folder.label)}"`,
        icon: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAwAAAAMCAYAAABWdVznAAAABHNCSVQICAgIfAhkiAAAAAlwSFlzAAAN1wAADdcBQiibeAAAABl0RVh0U29mdHdhcmUAd3d3Lmlua3NjYXBlLm9yZ5vuPBoAAADFSURBVCiRrdEtTkMBEATgb19C0gsgEEgMFW2TooAURzgACoNAorgAB6jqAVBcghBQYPmxBAQeBYYQ4C2CJvTlPUibMG53ZpKZ3chMs6Bo3N7EwG2sTG9Ih9J+ExW1SFexpnCBNyzq5VPdcB2bwi4WsIz5Mf+OR9wrjHTy9DvSi3MEBhNimMOScKfj7KfDRn54sIPjhj5D3Twgy2rp7fwUTuotvU6O1SuVVseiSxyhRPt3Q2hJW7q5rpd7Cn08VyT/8+k/8AVY7Dd1pA43RAAAAABJRU5ErkJggg==',
        position: new L.LatLng(...bookmark.latlng.split(',')),
        guid: bookmark.guid,
        onSelected: window.plugin.bookmarks.onSearchResultSelected,
      });
    });
  });
};

window.plugin.bookmarks.onSearchResultSelected = function (result, event) {
  if (result.guid) {
    // portal
    var guid = result.guid;
    if (event.type === 'dblclick') IITC.portal.zoomToAndShow(guid, result.position);
    else if (window.portals[guid]) IITC.portal.display.renderDetails(guid);
    else IITC.portal.selectByLatLng(result.position);
  } else if (result.zoom) {
    // map
    window.map.setView(result.position, result.zoom);
  }
  return true; // prevent default behavior
};

/** *************************************************************************************************************************************************************/

// Saved the new sort of the folders (in the localStorage)
window.plugin.bookmarks.sortFolder = function (typeList) {
  var keyType = typeList.replace('bkmrk_', '');

  var newArr = {};
  $(`#${typeList} li.bookmarkFolder`).each(function () {
    var idFold = $(this).attr('id');
    newArr[idFold] = window.plugin.bookmarks.currentProject[keyType][idFold];
  });
  window.plugin.bookmarks.currentProject[keyType] = newArr;
  window.plugin.bookmarks.saveStorage();

  window.runHooks('pluginBkmrksEdit', { target: 'folder', action: 'sort' });
  console.log('BOOKMARKS: sorted folder');
};

// Saved the new sort of the bookmarks (in the localStorage)
window.plugin.bookmarks.sortBookmark = function (typeList) {
  var keyType = typeList.replace('bkmrk_', '');
  var newArr = {};

  $(`#${typeList} li.bookmarkFolder`).each(function () {
    var idFold = $(this).attr('id');
    newArr[idFold] = window.plugin.bookmarks.currentProject[keyType][idFold];
    newArr[idFold].bkmrk = {};
  });

  $(`#${typeList} li.bkmrk`).each(function () {
    window.plugin.bookmarks.loadStorage();

    var idFold = $(this).parent().parent('li').attr('id');
    var id = $(this).attr('id');

    var list = window.plugin.bookmarks.currentProject[keyType];
    for (var idFoldersOrigin in list) {
      for (var idBkmrk in list[idFoldersOrigin]['bkmrk']) {
        if (idBkmrk === id) {
          newArr[idFold].bkmrk[id] = window.plugin.bookmarks.currentProject[keyType][idFoldersOrigin].bkmrk[id];
        }
      }
    }
  });
  window.plugin.bookmarks.currentProject[keyType] = newArr;
  window.plugin.bookmarks.saveStorage();
  window.runHooks('pluginBkmrksEdit', { target: 'bookmarks', action: 'sort' });
  console.log('BOOKMARKS: sorted bookmark (portal/map)');
};

window.plugin.bookmarks.jquerySortableScript = function () {
  $('.bookmarkList > ul').sortable({
    items: 'li.bookmarkFolder:not(.othersBookmarks)',
    handle: '.bookmarksAnchor',
    placeholder: 'sortable-placeholder',
    helper: 'clone', // fix accidental click in firefox
    forcePlaceholderSize: true,
    update: function (event, ui) {
      var typeList = ui.item.parent().parent('.bookmarkList').attr('id');
      window.plugin.bookmarks.sortFolder(typeList);
    },
  });

  $('.bookmarkList ul li ul').sortable({
    items: 'li.bkmrk',
    connectWith: '.bookmarkList ul ul',
    handle: '.bookmarksLink',
    placeholder: 'sortable-placeholder',
    helper: 'clone', // fix accidental click in firefox
    forcePlaceholderSize: true,
    update: function (event, ui) {
      var typeList = ui.item.parent().parent().parent().parent('.bookmarkList').attr('id');
      window.plugin.bookmarks.sortBookmark(typeList);
    },
  });
};

/** ************************************************************************************************************************************************************/
/** OPTIONS ****************************************************************************************************************************************************/
/** ************************************************************************************************************************************************************/
/**
 * Opens the plugin's page of the options window, which replaces the options dialog
 *
 * @deprecated use `IITC.options.open('bookmarks')` instead
 */
window.plugin.bookmarks.manualOpt = () => IITC.options.open('bookmarks');

// the stored bookmarks, with characters beyond ASCII escaped, for an export
window.plugin.bookmarks.exportData = () => window.plugin.bookmarks.escapeUnicode(localStorage.getItem(window.plugin.bookmarks.KEY_STORAGE));

window.plugin.bookmarks.optExport = function () {
  IITC.utils.exportFile(window.plugin.bookmarks.exportData(), 'IITC-bookmarks.json', 'application/json');
};

/**
 * Replaces all bookmarks with exported ones
 *
 * @param {string} text - Bookmarks as exported
 * @returns {string} What was imported
 * @throws {Error} When the text is not bookmarks
 */
window.plugin.bookmarks.importData = (text) => {
  let data;
  try {
    data = JSON.parse(text); // try to parse JSON first
  } catch (e) {
    console.warn('BOOKMARKS: failed to import data: ' + e);
    throw new Error('These are not bookmarks');
  }
  // stored as is, so anything else would break the plugin on the next load
  const isList = (list) => list !== null && typeof list === 'object' && !Array.isArray(list);
  if (!isList(data) || !isList(data.maps) || !isList(data.portals)) throw new Error('These are not bookmarks');
  localStorage.setItem(window.plugin.bookmarks.KEY_STORAGE, text);
  window.plugin.bookmarks.refreshBkmrks();
  window.runHooks('pluginBkmrksEdit', { target: 'all', action: 'import' });
  console.log('BOOKMARKS: reset and imported bookmarks');
  return 'Imported bookmarks';
};

/**
 * Lets the user pick a file of bookmarks, which replace all bookmarks
 *
 * @returns {Promise<string|undefined>} What was imported, undefined when no file was picked
 */
window.plugin.bookmarks.optImport = async () => {
  const [file] = await IITC.utils.importFile({ accept: 'application/json' });
  return file ? window.plugin.bookmarks.importData(file.text) : undefined;
};

window.plugin.bookmarks.optReset = function () {
  var promptAction = confirm('All bookmarks will be deleted. Are you sure?', '');
  if (promptAction) {
    delete localStorage[window.plugin.bookmarks.KEY_STORAGE];
    window.plugin.bookmarks.createStorage();
    window.plugin.bookmarks.loadStorage();
    window.plugin.bookmarks.refreshBkmrks();
    window.runHooks('pluginBkmrksEdit', { target: 'all', action: 'reset' });
    console.log('BOOKMARKS: reset all bookmarks');
    return 'Deleted all bookmarks';
  }
  return undefined;
};

// keeps or resets the position of the bookmarks box; the box is on the desktop only
window.plugin.bookmarks.optBox = function (command) {
  if (!window.isApp) {
    switch (command) {
      case 'save':
        var boxX = parseInt($('#bookmarksBox').css('top'));
        var boxY = parseInt($('#bookmarksBox').css('left'));
        window.plugin.bookmarks.statusBox.pos = { x: boxX, y: boxY };
        window.plugin.bookmarks.saveStorageBox();
        return 'Position saved';
      case 'reset':
        $('#bookmarksBox').css({ top: 100, left: 100 });
        window.plugin.bookmarks.optBox('save');
        return 'Position reset';
    }
  } else {
    throw new Error('Only on IITC for desktop');
  }
  return undefined;
};

window.plugin.bookmarks.dialogLoadListFolders = function (idBox, clickAction, showOthersF, scanType /* 0 = maps&portals; 1 = maps; 2 = portals*/) {
  var list = JSON.parse(localStorage[window.plugin.bookmarks.KEY_STORAGE]);
  var listHTML = '';
  var foldHTML = '';
  var elemGenericFolder = '';

  // For each type and folder
  for (var type in list) {
    if (scanType === 0 || (scanType === 1 && type === 'maps') || (scanType === 2 && type === 'portals')) {
      listHTML += '<h3>' + type + ':</h3>';

      for (var idFolders in list[type]) {
        var label = list[type][idFolders]['label'];

        // Create a folder
        foldHTML = `<div class="bookmarkFolder" id="${idFolders}" data-type="${type}" data-id="${idFolders}" onclick="${clickAction}(this);return false;">${label}</div>`;

        if (idFolders !== window.plugin.bookmarks.KEY_OTHER_BKMRK) {
          listHTML += foldHTML;
        } else {
          if (showOthersF === true) {
            elemGenericFolder = foldHTML;
          }
        }
      }
    }
    listHTML += elemGenericFolder;
    elemGenericFolder = '';
  }

  // Append all folders
  var r = `<div class="bookmarksDialog" id="${idBox}">${listHTML}</div>`;
  return r;
};

// the folders of both kinds of bookmarks, except the folder of the bookmarks outside any folder
window.plugin.bookmarks.folders = () =>
  ['maps', 'portals'].flatMap((type) =>
    Object.entries(window.plugin.bookmarks.currentProject?.[type] ?? {})
      .filter(([id]) => id !== window.plugin.bookmarks.KEY_OTHER_BKMRK)
      // labels are stored escaped for the bookmarks box, which shows them as HTML
      .map(([id, folder]) => ({ id: `${type}/${id}`, title: `${window.plugin.bookmarks.unescapeHtml(folder.label)} (${type})`, type, folderId: id }))
  );

/**
 * Asks for a new name of a folder in a dialog that shows the current one, and renames it
 *
 * @param {string} type - 'maps' or 'portals'
 * @param {string} idFold - Folder id
 * @returns {Promise<string|undefined>} What was done, undefined when no name was given
 */
window.plugin.bookmarks.renameFolder = async (type, idFold) => {
  const folder = window.plugin.bookmarks.currentProject[type][idFold];
  const name = await IITC.utils.promptText({ title: 'Rename folder', value: window.plugin.bookmarks.unescapeHtml(folder.label) });
  if (name === undefined) return undefined;

  folder.label = window.plugin.bookmarks.escapeHtml(name);
  window.plugin.bookmarks.saveStorage();
  window.plugin.bookmarks.refreshBkmrks();
  window.runHooks('pluginBkmrksEdit', { target: 'all', action: 'import' });

  console.log('BOOKMARKS: renamed bookmarks folder');
  return 'Renamed';
};

window.plugin.bookmarks.registerOptions = () => {
  IITC.options.register('bookmarks', {
    title: 'Bookmarks',
    shortcut: { label: 'Bookmarks Opt' },
    blocks: [
      {
        type: 'export',
        title: 'Export bookmarks',
        description: 'Bookmarks and folders, as text or a file',
        data: () => window.plugin.bookmarks.exportData(),
        filename: 'IITC-bookmarks.json',
        dataType: 'application/json',
      },
      {
        type: 'import',
        title: 'Import bookmarks',
        description: 'From text or a file; replaces all bookmarks',
        onData: (text) => window.plugin.bookmarks.importData(text),
        accept: 'application/json',
      },
      { type: 'heading', title: 'Folders' },
      {
        type: 'text',
        text: 'No folders yet. Add one with + Folder in the bookmarks',
        visible: () => !window.plugin.bookmarks.folders().length,
      },
      {
        type: 'repeat',
        over: () => window.plugin.bookmarks.folders(),
        blocks: [{ type: 'action', title: 'Rename', action: (folder) => window.plugin.bookmarks.renameFolder(folder.type, folder.folderId) }],
      },
      { type: 'heading', title: 'Bookmarks box', visible: () => !window.isApp },
      {
        type: 'action',
        title: 'Box position',
        description: 'Keeps the box where it is now',
        button: 'Save',
        visible: () => !window.isApp,
        action: () => window.plugin.bookmarks.optBox('save'),
      },
      {
        type: 'action',
        title: 'Default box position',
        description: 'Moves the box back to the top left corner',
        button: 'Reset',
        visible: () => !window.isApp,
        action: () => window.plugin.bookmarks.optBox('reset'),
      },
      { type: 'heading', title: 'Danger zone' },
      {
        type: 'action',
        title: 'Delete all bookmarks',
        description: 'Bookmarks and folders; asks before deleting, cannot be undone',
        button: 'Delete',
        action: () => window.plugin.bookmarks.optReset(),
      },
    ],
  });
};

/** ************************************************************************************************************************************************************/
/** AUTO DRAW **************************************************************************************************************************************************/
/** ************************************************************************************************************************************************************/
window.plugin.bookmarks.dialogDrawer = function () {
  window.dialog({
    html: window.plugin.bookmarks.dialogLoadList,
    dialogClass: 'ui-dialog-autodrawer',
    id: 'plugin-bookmarks-move-bookmark',
    title: 'Bookmarks - Auto Draw',
    buttons: {
      DRAW: function () {
        window.plugin.bookmarks.draw(0);
      },
      'DRAW&VIEW': function () {
        window.plugin.bookmarks.draw(1);
      },
    },
  });
  window.plugin.bookmarks.autoDrawOnSelect();
};

window.plugin.bookmarks.draw = function (view) {
  var latlngs = [];
  $('#bkmrksAutoDrawer a.bkmrk.selected').each(function (i) {
    var tt = $(this).data('latlng');
    latlngs[i] = tt;
  });

  if (latlngs.length >= 2 && latlngs.length <= 3) {
    // TODO: add an API to draw-tools rather than assuming things about its internals

    var layer, layerType;
    if (latlngs.length === 2) {
      layer = L.geodesicPolyline(latlngs, window.plugin.drawTools.lineOptions);
      layerType = 'polyline';
    } else {
      layer = L.geodesicPolygon(latlngs, window.plugin.drawTools.polygonOptions);
      layerType = 'polygon';
    }

    window.map.fire('draw:created', {
      layer: layer,
      layerType: layerType,
    });

    if ($('#bkmrkClearSelection').prop('checked')) $('#bkmrksAutoDrawer a.bkmrk.selected').removeClass('selected');

    if (window.plugin.bookmarks.isSmart) {
      window.show('map');
    }

    // Shown the layer if it is hidden
    if (!window.map.hasLayer(window.plugin.drawTools.drawnItems)) {
      window.map.addLayer(window.plugin.drawTools.drawnItems);
    }

    if (view) {
      window.map.fitBounds(layer.getBounds());
    }
  }
};

window.plugin.bookmarks.autoDrawOnSelect = function () {
  var latlngs = [];
  $('#bkmrksAutoDrawer a.bkmrk.selected').each(function (i) {
    var tt = $(this).data('latlng');
    latlngs[i] = tt;
  });

  var text = 'You must select 2 or 3 portals!';
  var color = 'red';

  function distanceElement(distance) {
    var text = window.formatDistance(distance);
    return distance >= 200000 ? '<em title="Long distance link" class="help longdistance">' + text + '</em>' : text;
  }

  if (latlngs.length === 2) {
    var distance = new L.LatLng(...latlngs[0]).distanceTo(latlngs[1]);
    text = 'Distance between portals: ' + distanceElement(distance);
    color = '';
  } else if (latlngs.length === 3) {
    var distances = latlngs.map(function (ll1, i, latlngs) {
      var ll2 = latlngs[(i + 1) % 3];
      return distanceElement(new L.LatLng(...ll1).distanceTo(ll2));
    });
    text = 'Distances: ' + distances.join(', ');
    color = '';
  }

  $('#bkmrksAutoDrawer p').html(text).css('color', color);
};

window.plugin.bookmarks.dialogLoadList = function () {
  var r = 'The "<a href="' + 'https://iitc.app/' + '" target="_BLANK"><strong>Draw Tools</strong></a>" plugin is required.</span>';

  if (!window.plugin.bookmarks || !window.plugin.drawTools) {
    $('.ui-dialog-autodrawer .ui-dialog-buttonset .ui-button:not(:first)').hide();
  } else {
    var portalsList = JSON.parse(localStorage[window.plugin.bookmarks.KEY_STORAGE]);
    var element = '';
    var elementTemp = '';
    var elemGenericFolder = '';

    // For each folder
    var list = portalsList.portals;
    for (var idFolders in list) {
      var folders = list[idFolders];

      // Create a label and a anchor for the sortable
      var folderLabel = `<a class="folderLabel" onclick="$(this).siblings('div').toggle();return false;">${folders['label']}</a>`;

      // Create a folder
      elementTemp = `<div class="bookmarkFolder" id="${idFolders}">${folderLabel}<div>`;

      // For each bookmark
      var fold = folders['bkmrk'];
      for (var idBkmrk in fold) {
        var bkmrk = fold[idBkmrk];
        var label = bkmrk['label'];
        var latlng = bkmrk['latlng'];

        // Create the bookmark
        elementTemp += `<a class="bkmrk" id="${idBkmrk}" onclick="$(this).toggleClass('selected');return false" data-latlng="[${latlng}]">${label}</a>`;
      }
      elementTemp += '</div></div>';

      if (idFolders !== window.plugin.bookmarks.KEY_OTHER_BKMRK) {
        element += elementTemp;
      } else {
        elemGenericFolder += elementTemp;
      }
    }
    element += elemGenericFolder;

    // Append all folders and bookmarks
    r =
      '<div id="bkmrksAutoDrawer">' +
      '<label style="margin-bottom: 9px; display: block;">' +
      '<input style="vertical-align: middle;" type="checkbox" id="bkmrkClearSelection" checked>' +
      ' Clear selection after drawing</label>' +
      '<p style="margin-bottom:9px;color:red">You must select 2 or 3 portals!</p>' +
      '<div onclick="window.plugin.bookmarks.autoDrawOnSelect();return false;">' +
      element +
      '</div>' +
      '</div>';
  }
  return r;
};

/** ************************************************************************************************************************************************************/
/** SYNC *******************************************************************************************************************************************************/
/** ************************************************************************************************************************************************************/
// Delay the syncing to group a few updates in a single request
window.plugin.bookmarks.delaySync = function () {
  if (!window.plugin.bookmarks.enableSync) return;
  clearTimeout(window.plugin.bookmarks.delaySync.timer);
  window.plugin.bookmarks.delaySync.timer = setTimeout(function () {
    window.plugin.bookmarks.delaySync.timer = null;
    window.plugin.bookmarks.syncNow();
  }, window.plugin.bookmarks.SYNC_DELAY);
};

// Store the updateQueue in updatingQueue and upload
window.plugin.bookmarks.syncNow = function () {
  if (!window.plugin.bookmarks.enableSync) return;
  $.extend(window.plugin.bookmarks.updatingQueue, window.plugin.bookmarks.updateQueue);
  window.plugin.bookmarks.updateQueue = {};
  window.plugin.bookmarks.storeLocal(window.plugin.bookmarks.UPDATING_QUEUE);
  window.plugin.bookmarks.storeLocal(window.plugin.bookmarks.UPDATE_QUEUE);

  window.plugin.sync.updateMap('bookmarks', window.plugin.bookmarks.SYNC_FIELD, Object.keys(window.plugin.bookmarks.updatingQueue));
};

// localStorage keys holding bookmarks: the default project plus any MPE projects
window.plugin.bookmarks.getAllProjectKeys = () => {
  const keys = [window.plugin.bookmarks.DEFAULT_KEY_STORAGE];
  keys.push(...(window.plugin.mpe?.obj?.projects?.bookmarks?.pj ?? []));
  return keys;
};

// the default project keeps the plain 'portals' and 'maps' keys, the only ones an older client reads
window.plugin.bookmarks.makeSyncKey = (storageKey, list) =>
  storageKey === window.plugin.bookmarks.DEFAULT_KEY_STORAGE ? list : storageKey + window.plugin.bookmarks.SYNC_KEY_DELIMITER + list;

window.plugin.bookmarks.parseSyncKey = (syncKey) => {
  const idx = syncKey.lastIndexOf(window.plugin.bookmarks.SYNC_KEY_DELIMITER);
  if (idx === -1) return { storageKey: window.plugin.bookmarks.DEFAULT_KEY_STORAGE, list: syncKey };
  return { storageKey: syncKey.slice(0, idx), list: syncKey.slice(idx + window.plugin.bookmarks.SYNC_KEY_DELIMITER.length) };
};

window.plugin.bookmarks.seedProject = (storageKey) => {
  let data = {};
  const raw = localStorage[storageKey];
  if (raw) {
    try {
      data = JSON.parse(raw);
    } catch {
      console.warn(`bookmarks: failed to parse localStorage[${storageKey}] while seeding sync`);
    }
  }

  window.plugin.bookmarks.LIST_TYPES.forEach((list) => {
    window.plugin.bookmarks.bkmrksObj[window.plugin.bookmarks.makeSyncKey(storageKey, list)] = data[list] ?? window.plugin.bookmarks.emptyList();
  });
};

window.plugin.bookmarks.seedSyncMap = () => {
  window.plugin.bookmarks.bkmrksObj = {};
  window.plugin.bookmarks.getAllProjectKeys().forEach(window.plugin.bookmarks.seedProject);
};

// a queued key with nothing behind it tells sync to drop it
window.plugin.bookmarks.queueProject = (storageKey) => {
  window.plugin.bookmarks.LIST_TYPES.forEach((list) => {
    window.plugin.bookmarks.updateQueue[window.plugin.bookmarks.makeSyncKey(storageKey, list)] = true;
  });
};

window.plugin.bookmarks.reconcileAfterMpeChange = (data) => {
  if (data?.data?.namespace !== 'bookmarks') return;

  const valid = new Set(window.plugin.bookmarks.getAllProjectKeys());
  const gone = new Set();
  const dropped = Object.keys(window.plugin.bookmarks.bkmrksObj).filter((syncKey) => {
    const { storageKey, list } = window.plugin.bookmarks.parseSyncKey(syncKey);
    // a mark outlives the project it belongs to
    if (list === window.plugin.bookmarks.DELETED_MARK || valid.has(storageKey)) return false;
    gone.add(storageKey);
    return true;
  });
  dropped.forEach((syncKey) => {
    delete window.plugin.bookmarks.bkmrksObj[syncKey];
    window.plugin.bookmarks.updateQueue[syncKey] = true;
  });
  gone.forEach((deletedKey) => {
    const mark = window.plugin.bookmarks.makeSyncKey(deletedKey, window.plugin.bookmarks.DELETED_MARK);
    window.plugin.bookmarks.bkmrksObj[mark] = Date.now();
    window.plugin.bookmarks.updateQueue[mark] = true;
  });

  // a project created a moment ago has no entry yet
  const storageKey = window.plugin.bookmarks.KEY_STORAGE;
  const isNew = !(window.plugin.bookmarks.makeSyncKey(storageKey, 'portals') in window.plugin.bookmarks.bkmrksObj);
  if (isNew) {
    window.plugin.bookmarks.seedProject(storageKey);
    window.plugin.bookmarks.queueProject(storageKey);
    // the project is back, so its mark goes
    const mark = window.plugin.bookmarks.makeSyncKey(storageKey, window.plugin.bookmarks.DELETED_MARK);
    delete window.plugin.bookmarks.bkmrksObj[mark];
    window.plugin.bookmarks.updateQueue[mark] = true;
  }

  if (dropped.length === 0 && !isNew) return;
  window.plugin.bookmarks.storeLocal(window.plugin.bookmarks.UPDATE_QUEUE);
  window.plugin.bookmarks.delaySync();
};

window.plugin.bookmarks.registerFieldForSyncing = () => {
  // sync may not be loaded yet, and fires this hook once it is
  if (!window.plugin.sync) {
    window.addHook('pluginSyncReady', window.plugin.bookmarks.registerFieldForSyncing);
    return;
  }
  window.plugin.bookmarks.seedSyncMap();
  window.addHook('mpe', window.plugin.bookmarks.reconcileAfterMpeChange);
  // MPE can register its projects after the seeding above, leaving them out of the map
  window.addHook('pluginMpeReady', window.plugin.bookmarks.seedSyncMap);
  window.plugin.sync.registerMapForSync(
    'bookmarks',
    window.plugin.bookmarks.SYNC_FIELD,
    window.plugin.bookmarks.syncCallback,
    window.plugin.bookmarks.syncInitialized
  );
};

// fullUpdated is set whenever the file was last written by another client, meaning sync has
// just replaced the map wholesale, so every project's localStorage is rebuilt from it
window.plugin.bookmarks.syncCallback = (pluginName, fieldName, e, fullUpdated) => {
  if (fieldName !== window.plugin.bookmarks.SYNC_FIELD || !fullUpdated) return;

  const byProject = {};
  const marked = new Map();
  Object.entries(window.plugin.bookmarks.bkmrksObj).forEach(([syncKey, folders]) => {
    const { storageKey, list } = window.plugin.bookmarks.parseSyncKey(syncKey);
    if (list === window.plugin.bookmarks.DELETED_MARK) {
      marked.set(storageKey, folders);
      return;
    }
    // a key some other client keeps in the same file
    if (!window.plugin.bookmarks.LIST_TYPES.includes(list)) return;
    (byProject[storageKey] ??= {})[list] = folders;
  });
  Object.entries(byProject).forEach(([storageKey, data]) => {
    window.plugin.bookmarks.LIST_TYPES.forEach((list) => (data[list] ??= window.plugin.bookmarks.emptyList()));
    localStorage[storageKey] = JSON.stringify(data);
  });

  let dropMark = false;
  marked.forEach((markedAt, storageKey) => {
    // the default project is never deleted, whatever the file says
    if (storageKey === window.plugin.bookmarks.DEFAULT_KEY_STORAGE) return;

    const recreated = storageKey in byProject;
    if (!recreated) delete localStorage[storageKey];

    // a mark is dropped once the project is back, or once it has outlived its purpose
    const age = Date.now() - (Number.isFinite(markedAt) ? markedAt : Date.now());
    if (recreated || age > window.plugin.bookmarks.DELETED_MARK_TTL) {
      const mark = window.plugin.bookmarks.makeSyncKey(storageKey, window.plugin.bookmarks.DELETED_MARK);
      delete window.plugin.bookmarks.bkmrksObj[mark];
      window.plugin.bookmarks.updateQueue[mark] = true;
      dropMark = true;
    }
  });

  // the project open right now may be one of those just deleted
  if (marked.has(window.plugin.bookmarks.KEY_STORAGE) && !(window.plugin.bookmarks.KEY_STORAGE in byProject)) {
    window.plugin.mpe?.action?.switchProject?.('bookmarks', window.plugin.bookmarks.DEFAULT_KEY_STORAGE);
  }

  // so MPE learns about projects that arrived or went away on another device
  window.plugin.mpe?.data?.scanStorageForOne?.('bookmarks');

  // an older client writes the file without these keys, so the local copy is kept and pushed back
  const missing = window.plugin.bookmarks.getAllProjectKeys().filter((storageKey) => !(storageKey in byProject));
  missing.forEach((storageKey) => {
    window.plugin.bookmarks.seedProject(storageKey);
    window.plugin.bookmarks.queueProject(storageKey);
  });
  if (missing.length > 0 || dropMark) {
    window.plugin.bookmarks.storeLocal(window.plugin.bookmarks.UPDATE_QUEUE);
    window.plugin.bookmarks.delaySync();
  }

  window.plugin.bookmarks.refreshBkmrks();
  window.plugin.bookmarks.resetAllStars();
  window.runHooks('pluginBkmrksSyncEnd', { target: 'all', action: 'sync' });
  console.log('BOOKMARKS: rebuilt from remote sync');
};

// syncing of the field is initialized, upload all queued update
window.plugin.bookmarks.syncInitialized = (pluginName, fieldName) => {
  if (fieldName !== window.plugin.bookmarks.SYNC_FIELD) return;
  window.plugin.bookmarks.enableSync = true;
  if (Object.keys(window.plugin.bookmarks.updateQueue).length > 0) {
    window.plugin.bookmarks.delaySync();
  }
};

window.plugin.bookmarks.storeLocal = function (mapping) {
  if (typeof window.plugin.bookmarks[mapping.field] !== 'undefined' && window.plugin.bookmarks[mapping.field] !== null) {
    localStorage[mapping.key] = JSON.stringify(window.plugin.bookmarks[mapping.field]);
  } else {
    localStorage.removeItem(mapping.key);
  }
};

window.plugin.bookmarks.syncBkmrks = function () {
  const storageKey = window.plugin.bookmarks.KEY_STORAGE;
  window.plugin.bookmarks.seedProject(storageKey);
  window.plugin.bookmarks.queueProject(storageKey);
  window.plugin.bookmarks.storeLocal(window.plugin.bookmarks.UPDATE_QUEUE);
  window.plugin.bookmarks.delaySync();
};

/** ************************************************************************************************************************************************************/
/** HIGHLIGHTER ************************************************************************************************************************************************/
/** ************************************************************************************************************************************************************/
window.plugin.bookmarks.highlight = function (data) {
  var guid = data.portal.options.ent[0];
  if (window.plugin.bookmarks.findByGuid(guid)) {
    data.portal.setStyle({ fillColor: 'red' });
  }
};

window.plugin.bookmarks.highlightRefresh = function (data) {
  if (window._current_highlighter === 'Bookmarked Portals') {
    if (
      data.action === 'sync' ||
      data.target === 'portal' ||
      (data.target === 'folder' && data.action === 'remove') ||
      (data.target === 'all' && data.action === 'import') ||
      (data.target === 'all' && data.action === 'reset') ||
      (data.target === 'all' && data.action === 'MPEswitch')
    ) {
      IITC.portal.highlighter.change('Bookmarked Portals');
    }
  }
};

/** ************************************************************************************************************************************************************/
/** BOOKMARKED PORTALS LAYER ***********************************************************************************************************************************/
/** ************************************************************************************************************************************************************/
window.plugin.bookmarks.addAllStars = function () {
  var list = window.plugin.bookmarks.currentProject.portals;

  for (var idFolders in list) {
    for (var idBkmrks in list[idFolders]['bkmrk']) {
      var latlng = list[idFolders]['bkmrk'][idBkmrks].latlng.split(',');
      var guid = list[idFolders]['bkmrk'][idBkmrks].guid;
      var lbl = list[idFolders]['bkmrk'][idBkmrks].label;
      window.plugin.bookmarks.addStar(guid, latlng, lbl);
    }
  }
};

window.plugin.bookmarks.resetAllStars = function () {
  for (const guid in window.plugin.bookmarks.starLayers) {
    var starInLayer = window.plugin.bookmarks.starLayers[guid];
    window.plugin.bookmarks.starLayerGroup.removeLayer(starInLayer);
    delete window.plugin.bookmarks.starLayers[guid];
  }
  window.plugin.bookmarks.addAllStars();
  console.log('resetAllStars done');
};

window.plugin.bookmarks.addStar = function (guid, latlng, lbl) {
  var star = new L.Marker(latlng, {
    title: lbl,
    icon: new L.Icon({
      iconUrl: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAoCAMAAACo9wirAAAAzFBMVEXbuTR9YwDd0T+ulyry2VDt53/s5Jv34a+tmUbJtGRtVwAtJADg14j304viyIZeSwDXyH5IOQD07JLPvnhqVQBuWACmkjpgTQBxWwC4p1WchikRDQCPdxeBaAQTDwADAgAOCwAAAAAAAAAAAAALCQAAAAAAAAAAAAD9+Jb97IT+3VT9+WH+0i3993D+80793Yr/yXL+5Tr+6XL+zEP/z2X+vSX+zB/+52L/qw393SX89xr9+yv/siP/vUf9+Dv+20P+rgH+xQv+vgH+twNAe/b8AAAAKHRSTlPywvLj+vn4/OLrqFb0/PSS8Hb77meB4FGX5t1A2dUkEy8HDQoaAwEAoclaPQAAAo1JREFUeF5VkeeyozAMRrPphdwkdIxpBu7SSe/llvd/p5VxlMx+PxiMzhxJuPX3mc/PzzgIQwYJwyCGoyggwMuRav6BmKrLGgQBrBvUkuQkkSWLGh5DooX1UNWlXplDyp6kq5EXCqL1qlu9srpfIPeq7FmaIBCIA9WScyjznC/3XOZEEAsABIFBoH6GUrt9v5zPQEAXFoCiAWLPkUqon+8lIbl4kRwfmggABFZSXXh9PhbopUos1fWCBoAJnT4MCMMlZLHQE/Hed/wIFA3gkiSvqjLtK45tO/N+WlZVnhA7YgKAFZK83dGJM5v4rmFSonfaeWotoEcDhJqSVl06W0A5gviTGelWqTJzvZADcWjO11XVIzPbjzzGPFfT4bxWTD8SAANgtTrIQ8eF3QPmDOXDarWej/mUL+C0SgfU91gcR3TAj42BNQDMAMDpwBfzwjCi/cMJgNFMGGBIY5g+AACnrWl+NJay0+mRDhcAiDVdKsOnzJqZRFGoZo74SaYTXDPwzPnhUTw6dCSnaT2inUdRHD7GNgIxM/QUvrW6WfZ4ZFm3VRSiA4sFEEaOlBX7oij2EP4ssqlj413wHqq13uy/X9lvYAcbb5P3cGmd7b9/nvneZzWdNB0EAApN2RZvoNjCvfKb4IBQ+LTe7H5+RXabmjwFCISw6Xb3i8D2oxEgwMdkBgHF7xeEC/SF34yIAN90/LHdHb94QCB2REBsauj17cqB660eogAB8bOE4vgUsBiBt2J6ux6P19v0OQECb8V8y4G34D+AKwgoQEBQgMBLYSrL222pjHEFBN4KOl0up/wWUIAA/k5tNBg014gCBPB3+s5g0EwYYB2Bl8KyND9CAQJvgnmq6kYeXxHzDyATueNnvZcYAAAAAElFTkSuQmCC',
      iconAnchor: [15, 40],
      iconSize: [30, 40],
    }),
  });
  window.registerMarkerForOMS(star);
  star.on('spiderfiedclick', function () {
    IITC.portal.display.renderDetails(guid);
  });

  window.plugin.bookmarks.starLayers[guid] = star;
  star.addTo(window.plugin.bookmarks.starLayerGroup);
};

window.plugin.bookmarks.editStar = function (data) {
  if (data.target === 'portal') {
    if (data.action === 'add') {
      var guid = data.guid;
      var latlng = window.portals[guid].getLatLng();
      var lbl = window.portals[guid].options.data.title;
      window.plugin.bookmarks.addStar(guid, latlng, lbl);
    } else if (data.action === 'remove') {
      var starInLayer = window.plugin.bookmarks.starLayers[data.guid];
      window.plugin.bookmarks.starLayerGroup.removeLayer(starInLayer);
      delete window.plugin.bookmarks.starLayers[data.guid];
    }
  } else if ((data.target === 'all' && (data.action === 'import' || data.action === 'reset')) || (data.target === 'folder' && data.action === 'remove')) {
    window.plugin.bookmarks.resetAllStars();
  }
};

/** ************************************************************************************************************************************************************/

window.plugin.bookmarks.setupPortalsList = function () {
  function onBookmarkChanged(data) {
    console.log(data, data.target, data.guid);

    if (data.target === 'portal' && data.guid) {
      if (window.plugin.bookmarks.findByGuid(data.guid)) $('[data-list-bookmark="' + data.guid + '"]').addClass('favorite');
      else $('[data-list-bookmark="' + data.guid + '"]').removeClass('favorite');
    } else {
      $('[data-list-bookmark]').each(function (i, element) {
        var guid = element.getAttribute('data-list-bookmark');
        if (window.plugin.bookmarks.findByGuid(guid)) $(element).addClass('favorite');
        else $(element).removeClass('favorite');
      });
    }
  }

  window.addHook('pluginBkmrksEdit', onBookmarkChanged);
  window.addHook('pluginBkmrksSyncEnd', onBookmarkChanged);

  window.plugin.portalslist.fields.unshift({
    // insert at first column
    title: '',
    value: function (portal) {
      return portal.options.guid;
    }, // we store the guid, but implement a custom comparator so the list does sort properly without closing and reopening the dialog
    sort: function (guidA, guidB) {
      var infoA = window.plugin.bookmarks.findByGuid(guidA);
      var infoB = window.plugin.bookmarks.findByGuid(guidB);
      if (infoA && !infoB) return 1;
      if (infoB && !infoA) return -1;
      return 0;
    },
    format: function (cell, portal, guid) {
      $(cell).addClass('portal-list-bookmark').attr('data-list-bookmark', guid);

      // for some reason, jQuery removes event listeners when the list is sorted. Therefore we use DOM's addEventListener
      $('<iitc-icon filled>star</iitc-icon>')
        .appendTo(cell)[0]
        .addEventListener(
          'click',
          function () {
            if (window.plugin.bookmarks.findByGuid(guid)) {
              window.plugin.bookmarks.switchStarPortal(guid);
            } else {
              window.plugin.bookmarks.addPortalBookmarkByMarker(portal, true);
            }
          },
          false
        );

      if (window.plugin.bookmarks.findByGuid(guid)) cell.className += ' favorite';
    },
  });
};

window.plugin.bookmarks.setupContent = function () {
  window.plugin.bookmarks.htmlBkmrksBox =
    '<div id="bookmarksBox">' +
    ' <div id="topBar">' +
    '  <a id="bookmarksMin" class="btn" onclick="window.plugin.bookmarks.switchStatusBkmrksBox(0);return false;" title="Minimize">-</a>' +
    '  <div class="handle">...</div>' +
    '  <a id="bookmarksDel" class="btn" onclick="window.plugin.bookmarks.deleteMode();return false;" title="Show/Hide \'X\' button">Show/Hide "X" button</a>' +
    ' </div>' +
    ' <div id="bookmarksTypeBar">' +
    '  <h5 class="bkmrk_maps current" onclick="window.plugin.bookmarks.switchPageBkmrksBox(this, 0);return false">Maps</h5>' +
    '  <h5 class="bkmrk_portals" onclick="window.plugin.bookmarks.switchPageBkmrksBox(this, 1);return false">Portals</h5>' +
    '  <div style="clear:both !important;"></div>' +
    ' </div>' +
    ' <div id="bkmrk_maps" class="bookmarkList current">' +
    '  <div class="addForm">' +
    '   <input placeholder="Insert label" />' +
    '   <a class="newMap" onclick="window.plugin.bookmarks.addElement(this, \'map\');return false;">+ Map</a>' +
    '   <a class="newFolder" onclick="window.plugin.bookmarks.addElement(this, \'folder\');return false;">+ Folder</a>' +
    '  </div>' +
    ' </div>' +
    ' <div id="bkmrk_portals" class="bookmarkList">' +
    '  <div class="addForm">' +
    '   <input placeholder="Insert label" />' +
    '   <a class="newFolder" onclick="window.plugin.bookmarks.addElement(this, \'folder\');return false;">+ Folder</a>' +
    '  </div>' +
    ' </div>' +
    ' <div style="border-bottom-width:1px;"></div>' +
    '</div>';

  window.plugin.bookmarks.htmlDisabledMessage = '<div title="Your browser do not support localStorage">Plugin Bookmarks disabled*.</div>';
  window.plugin.bookmarks.htmlStar =
    '<a class="bkmrksStar" accesskey="b" onclick="window.plugin.bookmarks.switchStarPortal();return false;" title="Save this portal in your bookmarks [b]"><iitc-icon filled>star</iitc-icon></a>';
  window.plugin.bookmarks.htmlMoveBtn =
    '<a id="bookmarksMove" class="btn" onclick="window.plugin.bookmarks.moveMode();return false;">Show/Hide "Move" button</a>';
};

/** ************************************************************************************************************************************************************/
window.plugin.bookmarks.initMPE = function () {
  // MPE may not be loaded yet, and fires this hook once it is
  if (!window.plugin.mpe) {
    window.addHook('pluginMpeReady', window.plugin.bookmarks.initMPE);
    return;
  }

  window.plugin.mpe.setMultiProjects({
    namespace: 'bookmarks',
    title: 'Bookmarks for Maps and Portals',
    icon: 'bookmark',
    fa: 'fa-bookmark',
    defaultKey: window.plugin.bookmarks.DEFAULT_KEY_STORAGE,
    func_setKey: function (newKey) {
      window.plugin.bookmarks.KEY_STORAGE = newKey;
    },
    func_post: function () {
      // Delete all Markers (stared portals)
      for (var guid in window.plugin.bookmarks.starLayers) {
        var starInLayer = window.plugin.bookmarks.starLayers[guid];
        window.plugin.bookmarks.starLayerGroup.removeLayer(starInLayer);
        delete window.plugin.bookmarks.starLayers[guid];
      }
      // Create Storage if not exist
      window.plugin.bookmarks.createStorage();
      // Load Storage
      window.plugin.bookmarks.loadStorage();
      // window.plugin.bookmarks.saveStorage();

      // Delete and Regenerate Bookmark Lists
      window.plugin.bookmarks.refreshBkmrks();

      // Add Markers (stared portals)
      window.plugin.bookmarks.addAllStars();

      // Refresh Highlighter
      window.plugin.bookmarks.highlightRefresh({ target: 'all', action: 'MPEswitch' });
    },
  });
};

/** ************************************************************************************************************************************************************/

var setup = function () {
  window.plugin.bookmarks.isSmart = IITC.utils.isSmartphone();
  window.plugin.bookmarks.registerOptions();

  // HOOKS:
  // - pluginBkmrksEdit:    fired when a bookmarks/folder is removed, added or sorted,
  //                        also when a folder is opened/closed.
  // - pluginBkmrksSyncEnd: fired when the sync is finished;

  // If the storage not exists or is a old version
  window.plugin.bookmarks.createStorage();
  window.plugin.bookmarks.upgradeToNewStorage();

  // Load data from localStorage
  window.plugin.bookmarks.loadStorage();
  window.plugin.bookmarks.loadStorageBox();
  window.plugin.bookmarks.setupContent();
  window.plugin.bookmarks.setupCSS();

  if (!window.plugin.bookmarks.isSmart) {
    $('body').append(window.plugin.bookmarks.htmlBkmrksBox);
    window.plugin.bookmarks.addBoxButton();
    $('#bookmarksBox').draggable({ handle: '.handle', containment: 'window' });
    $(
      '#bookmarksBox #bookmarksMin , #bookmarksBox ul li, #bookmarksBox ul li a, #bookmarksBox ul li a span, #bookmarksBox h5, #bookmarksBox .addForm a'
    ).disableSelection();
    $('#bookmarksBox').css({ top: window.plugin.bookmarks.statusBox.pos.x, left: window.plugin.bookmarks.statusBox.pos.y });
  } else {
    $('body').append(window.plugin.bookmarks.htmlBkmrksBox);
    $('#bookmarksBox').css('display', 'none').addClass('mobile');

    if (window.useAppPanes()) window.app.addPane('plugin-bookmarks', 'Bookmarks', 'bookmark');
    window.addHook('paneChanged', window.plugin.bookmarks.onPaneChanged);
  }
  IITC.toolbox.addButton({
    label: 'Auto draw',
    title: 'Draw lines/triangles between bookmarked portals [q]',
    action: window.plugin.bookmarks.dialogDrawer,
    accesskey: 'q',
  });

  if (window.plugin.bookmarks.isSmart) {
    // $('#bookmarksBox.mobile #topBar').prepend(window.plugin.bookmarks.htmlCallSetBox+window.plugin.bookmarks.htmlCalldrawBox); // wonk in progress
    $('#bookmarksBox.mobile #topBar').append(window.plugin.bookmarks.htmlMoveBtn);
  }

  window.plugin.bookmarks.loadList('maps');
  window.plugin.bookmarks.loadList('portals');
  window.plugin.bookmarks.jquerySortableScript();

  if (window.plugin.bookmarks.statusBox['show'] === 0) {
    window.plugin.bookmarks.switchStatusBkmrksBox(0);
  }
  if (window.plugin.bookmarks.statusBox['page'] === 1) {
    $('#bookmarksBox h5.bkmrk_portals').trigger('click');
  }

  window.addHook('portalSelected', window.plugin.bookmarks.onPortalSelected);
  window.addHook('portalDetailsUpdated', window.plugin.bookmarks.onPortalSelected);
  window.addHook('search', window.plugin.bookmarks.onSearch);

  // MPE has to know the projects before syncing seeds them
  window.plugin.bookmarks.initMPE();

  // Sync
  window.addHook('pluginBkmrksEdit', window.plugin.bookmarks.syncBkmrks);
  window.plugin.bookmarks.registerFieldForSyncing();

  // Highlighter - bookmarked portals
  window.addHook('pluginBkmrksEdit', window.plugin.bookmarks.highlightRefresh);
  window.addHook('pluginBkmrksSyncEnd', window.plugin.bookmarks.highlightRefresh);
  IITC.portal.highlighter.add('Bookmarked Portals', window.plugin.bookmarks.highlight);

  // Layer - Bookmarked portals
  window.plugin.bookmarks.starLayerGroup = new L.LayerGroup();
  window.layerChooser.addOverlay(window.plugin.bookmarks.starLayerGroup, 'Bookmarked Portals', { default: false });
  window.plugin.bookmarks.addAllStars();
  window.addHook('pluginBkmrksEdit', window.plugin.bookmarks.editStar);
  window.addHook('pluginBkmrksSyncEnd', window.plugin.bookmarks.resetAllStars);

  if (window.plugin.portalslist) {
    window.plugin.bookmarks.setupPortalsList();
  }
};
// moved setupCSS to the end to improve readability of built script
window.plugin.bookmarks.setupCSS = function () {
  $('<style>').prop('type', 'text/css').html('\
#bookmarksBox :not(iitc-icon){text-indent:0;box-sizing:border-box;width:auto;height:auto;margin:0;padding:0;font-family:Verdana,Geneva,sans-serif;font-size:13px;line-height:20px;text-decoration:none;display:block}#bookmarksBox{z-index:4001;width:231px;height:auto;display:block;top:100px;left:100px;overflow:hidden;position:absolute!important}#bookmarksBox .addForm,#bookmarksBox #bookmarksTypeBar,#bookmarksBox h5{color:#fff;height:28px;font-size:14px;overflow:hidden}#bookmarksBox #topBar{height:15px!important}#bookmarksBox #topBar *{float:left!important;height:14px!important}#bookmarksBox .handle{text-align:center;color:#fff;cursor:move;width:80%;line-height:6px}#bookmarksBox #topBar .btn{cursor:pointer;color:#20a8b1;text-align:center;width:10%;font-size:18px;font-weight:700;line-height:13px;display:block}#bookmarksBox #topBar #bookmarksDel{text-indent:-999px;background:#b42e2e;overflow:hidden}#bookmarksBox #topBar #bookmarksMin:hover{color:#ffce00}#bookmarksBox #bookmarksTypeBar{clear:both}#bookmarksBox h5{text-align:center;color:#788;width:50%;padding:4px 0 23px;height:93px!important}#bookmarksBox h5.current{cursor:default;background:0;color:#fff!important}#bookmarksBox h5:hover{color:#ffce00;background:0 0}#bookmarksBox #topBar,#bookmarksBox .addForm,#bookmarksBox #bookmarksTypeBar,#bookmarksBox .bookmarkList li.bookmarksEmpty,#bookmarksBox .bookmarkList li.bkmrk a,#bookmarksBox .bookmarkList li.bkmrk:hover{background-color:#08304ed9}#bookmarksBox h5,#bookmarksBox .bookmarkList li.bkmrk:hover .bookmarksLink,#bookmarksBox .addForm *{background:#0000004d}#bookmarksBox .addForm *{float:left;display:block;height:28px!important}#bookmarksBox .addForm a{cursor:pointer;color:#20a8b1;text-align:center;width:35%;padding:4px 0 23px;font-size:12px;line-height:20px}#bookmarksBox .addForm a:hover{color:#000;background:#ffce00;text-decoration:none}#bookmarksBox .addForm input{color:#ffce00;height:28px;padding:0 8px 1px;font-size:12px;line-height:12px;font-size:11px!important}#bookmarksBox #bkmrk_portals .addForm input{width:65%}#bookmarksBox #bkmrk_maps .addForm input{width:42%}#bookmarksBox #bkmrk_maps .addForm a{width:29%}#bookmarksBox .addForm input:hover,#bookmarksBox .addForm input:focus{background:#0009;outline:0}#bookmarksBox .bookmarkList>ul{clear:both;color:#fff;max-height:580px;list-style-type:none;overflow:hidden auto}#bookmarksBox .sortable-placeholder{background:#08304e8c;box-shadow:inset 1px 0 #20a8b1}#bookmarksBox .ui-sortable-helper{border-top-width:1px}#bookmarksBox .bookmarkList{display:none}#bookmarksBox .bookmarkList.current{display:block}#bookmarksBox h5,#bookmarksBox .addForm *,#bookmarksBox ul li.bkmrk,#bookmarksBox ul li.bkmrk a{height:22px}#bookmarksBox h5,#bookmarksBox ul li.bkmrk a{cursor:pointer;float:left;overflow:hidden}#bookmarksBox ul .bookmarksEmpty{text-indent:27px;color:#eee}#bookmarksBox ul .bookmarksRemoveFrom{text-align:center;color:#fff;width:10%}#bookmarksBox .bookmarksRemoveFrom iitc-icon{line-height:18px}#bookmarksBox ul .bookmarksLink{color:#ffce00;width:90%;padding:0 10px 0 8px}#bookmarksBox ul .bookmarksLink.selected{color:#03fe03}#bookmarksBox ul .othersBookmarks .bookmarksLink{width:90%}#bookmarksBox ul .bookmarksLink:hover{color:#03fe03}#bookmarksBox ul .bookmarksRemoveFrom:hover{color:#fff;background:#e22!important}#bookmarksBox,#bookmarksBox *{border:0 solid #20a8b1}#bookmarksBox #topBar,#bookmarksBox ul .bookmarkFolder{border-top-width:1px}#bookmarksBox #topBar,#bookmarksBox #bookmarksTypeBar,#bookmarksBox .addForm,#bookmarksBox ul .bookmarkFolder .folderLabel,#bookmarksBox ul li.bkmrk a{border-bottom-width:1px}#bookmarksBox ul .bookmarkFolder{border-left-width:1px;border-right-width:1px}#bookmarksBox #topBar *,#bookmarksBox #bookmarksTypeBar *,#bookmarksBox .addForm *,#bookmarksBox ul li.bkmrk{border-left-width:1px}#bookmarksBox #topBar,#bookmarksBox #bookmarksTypeBar,#bookmarksBox .addForm,#bookmarksBox ul .bookmarksRemoveFrom{border-right-width:1px}#bookmarksBox ul .bookmarkFolder.othersBookmarks li.bkmrk,#bookmarksBox ul .bookmarkFolder .folderLabel .bookmarksRemoveFrom{border-left-width:0}.portal-list-bookmark iitc-icon{cursor:pointer;margin:-4px -3px -2px;font-size:19px}.bkmrksStar iitc-icon{float:left;min-width:var(--icon-target-size,24px);min-height:var(--icon-target-size,24px);justify-content:center;align-items:center;margin:0 0 0 2px;display:inline-flex}.bkmrksStar iitc-icon,.bkmrksStar.favorite:focus iitc-icon{color:var(--color-none)}.bkmrksStar:focus iitc-icon,.bkmrksStar.favorite iitc-icon,.portal-list-bookmark.favorite iitc-icon{color:var(--color-primary)}body.icons-unavailable .bkmrksStar iitc-icon:before,body.icons-unavailable .portal-list-bookmark iitc-icon:before{content:"☆"}body.icons-unavailable .bkmrksStar.favorite iitc-icon:before,body.icons-unavailable .portal-list-bookmark.favorite iitc-icon:before{content:"★"}#bookmarksBox .bookmarkList .bookmarkFolder{background:#083a4eb3;height:auto;margin-top:-1px;overflow:hidden}#bookmarksBox .bookmarkList ul li.sortable-placeholder{background:#083a4ee6;box-shadow:inset -1px 0 #20a8b1,inset 1px 0 #20a8b1,0 -1px #20a8b1}#bookmarksBox .bookmarkList .bkmrk.ui-sortable-helper{border-right-width:1px;border-left-width:1px!important}#bookmarksBox .bookmarkList ul li ul li.sortable-placeholder{height:23px;box-shadow:inset 0 -1px #20a8b1,inset 1px 0 #20a8b1}#bookmarksBox .bookmarkList ul li.bookmarkFolder.ui-sortable-helper,#bookmarksBox .bookmarkList ul li.othersBookmarks ul li.sortable-placeholder{box-shadow:inset 0 -1px #20a8b1}#bookmarksBox #topBar #bookmarksDel,#bookmarksBox .bookmarkList .bookmarkFolder .folderLabel:hover .bookmarksRemoveFrom,#bookmarksBox .bookmarkList .bookmarkFolder .folderLabel:hover .bookmarksAnchor{border-bottom-width:1px}#bookmarksBox .bookmarkList .bookmarkFolder .folderLabel .bookmarksAnchor span,#bookmarksBox .bookmarkList .bookmarkFolder .folderLabel>span,#bookmarksBox .bookmarkList .bookmarkFolder .folderLabel>span>span,#bookmarksBox .bookmarkList .triangle{width:0;height:0}#bookmarksBox .bookmarkList .bookmarkFolder .folderLabel{cursor:pointer;text-indent:0;background:#069;height:25px;overflow:visible}#bookmarksBox .bookmarkList .bookmarkFolder .folderLabel>*{float:left;height:25px}#bookmarksBox .bookmarkList .bookmarkFolder .folderLabel .bookmarksAnchor{color:#fff;width:90%;line-height:25px}#bookmarksBox .bookmarkList .bookmarkFolder .folderLabel .bookmarksAnchor span{float:left;border-width:5px 0 5px 7px;border-color:#0000 #0000 #0000 #fff;margin:7px 7px 0 6px}#bookmarksBox .bookmarkList .bookmarkFolder.open .folderLabel .bookmarksAnchor span{border-width:7px 5px 0;border-color:#fff #0000 #0000;margin:9px 5px 0}#bookmarksBox .bookmarkList .bookmarkFolder .folderLabel>span,#bookmarksBox .bookmarkList .bookmarkFolder .folderLabel>span>span{border-width:0 12px 10px 0;border-color:#0000 #20a8b1 #0000 #0000;margin:-20px 0 0;display:none;position:relative;top:21px;left:219px}#bookmarksBox .bookmarkList .bookmarkFolder .folderLabel>span>span{border-width:0 10px 9px 0;border-color:#0000 #069 #0000 #0000;top:18px;left:0}#bookmarksBox .bookmarkList .bookmarkFolder.open .folderLabel>span,#bookmarksBox .bookmarkList .bookmarkFolder.open .folderLabel>span>span{display:none}#bookmarksBox .bookmarkList .bookmarkFolder.open .folderLabel:hover>span>span{border-color:#0000 #036 #0000 #0000}#bookmarksBox .bookmarkList .bookmarkFolder .folderLabel:hover .bookmarksAnchor{background:#036}#bookmarksBox .bookmarkList .bookmarkFolder ul{margin-left:10%;display:none}#bookmarksBox .bookmarkList .bookmarkFolder.open ul{min-height:22px;display:block}#bookmarksBox .bookmarkFolder.othersBookmarks ul{margin-left:0}#bookmarksBox .bookmarksRemoveFrom{display:none!important}#bookmarksBox.deleteMode .bookmarksRemoveFrom{display:block!important}#bookmarksBox .bookmarkList .bookmarkFolder .folderLabel .bookmarksAnchor,#bookmarksBox ul .bookmarksLink,#bookmarksBox ul .othersBookmarks .bookmarksLink{width:100%!important}#bookmarksBox.deleteMode .bookmarkList .bookmarkFolder .folderLabel .bookmarksAnchor,#bookmarksBox.deleteMode ul .bookmarksLink,#bookmarksBox.deleteMode ul .othersBookmarks .bookmarksLink{width:90%!important}#bookmarksBox.mobile{box-sizing:border-box;padding-top:var(--safe-area-inset-top);padding-bottom:var(--safe-area-inset-bottom);padding-left:var(--safe-area-inset-left);padding-right:var(--safe-area-inset-right);background:0 0!important;border:0!important;width:100%!important;height:100%!important;margin:0!important;position:absolute!important;top:0!important;left:0!important;overflow:auto!important}#bookmarksBox.mobile .bookmarkList ul,#bookmarksBox.mobile .bookmarkList ul li,#bookmarksBox.mobile .bookmarkList.current,#bookmarksBox.mobile .bookmarkList li.bookmarkFolder.open ul{width:100%!important;display:block!important}#bookmarksBox.mobile *{box-shadow:none!important;border-width:0!important}#bookmarksBox.mobile #topBar #bookmarksMin,#bookmarksBox.mobile #topBar .handle{display:none!important}#bookmarksBox.mobile #bookmarksTypeBar h5{cursor:pointer;text-align:center;float:left;width:50%;padding:7px 0;height:auto!important}#bookmarksBox.mobile #bookmarksTypeBar h5.current{cursor:default;color:#fff}#bookmarksBox.mobile #bookmarksTypeBar,#bookmarksBox.mobile .bookmarkList .addForm{border-bottom:1px solid #20a8b1!important}#bookmarksBox.mobile .bookmarkList ul li ul li.bkmrk,#bookmarksBox.mobile .bookmarkList li.bookmarkFolder .folderLabel{clear:both;height:36px!important}#bookmarksBox.mobile .bookmarkList li.bookmarkFolder .folderLabel a,#bookmarksBox.mobile .bookmarkList ul li ul li.bkmrk a{background:0 0;height:auto;padding:7px 0;box-shadow:inset 0 1px #20a8b1!important}#bookmarksBox.mobile .bookmarkList li.bookmarkFolder a.bookmarksRemoveFrom,#bookmarksBox.mobile .bookmarkList li.bkmrk a.bookmarksRemoveFrom{width:10%;background:0 0!important;box-shadow:inset 0 1px #20a8b1,inset -1px 0 #20a8b1!important}#bookmarksBox.mobile .bookmarkList li.bookmarkFolder a.bookmarksAnchor,#bookmarksBox.mobile .bookmarkList li.bkmrk a.bookmarksLink{text-indent:10px;height:36px;line-height:24px;overflow:hidden}#bookmarksBox.mobile .bookmarkList ul li.bookmarkFolder ul{margin-left:0!important}#bookmarksBox.mobile .bookmarkList>ul{border-bottom:1px solid #20a8b1!important}#bookmarksBox.mobile .bookmarkList .bookmarkFolder.othersBookmarks ul{border-top:5px solid #20a8b1!important}#bookmarksBox.mobile .bookmarkList li.bookmarkFolder,#bookmarksBox.mobile .bookmarkList li.bkmrk{box-shadow:inset 0 1px #20a8b1,1px 0 #20a8b1,-1px 1px #20a8b1!important}#bookmarksBox.mobile .bookmarkList>ul{max-height:none}#bookmarksBox.mobile .bookmarkList li.bookmarkFolder .folderLabel{box-shadow:0 1px #20a8b1!important}#bookmarksBox.mobile .bookmarkList ul li.bookmarkFolder ul{width:90%!important;margin-left:10%!important}#bookmarksBox.mobile .bookmarkList ul li.bookmarkFolder.othersBookmarks ul{width:100%!important;margin-left:0%!important}#bookmarksBox.mobile{margin-bottom:5px!important}#bookmarksBox.mobile #bookmarksTypeBar{height:auto}#bookmarksBox.mobile .addForm,#bookmarksBox.mobile .addForm *{padding:0;height:35px!important}#bookmarksBox.mobile .addForm a{line-height:37px}#bookmarksBox.mobile .addForm input{text-indent:10px}#bookmarksBox.mobile #bookmarksTypeBar h5,#bookmarksBox.mobile .bookmarkList .addForm a{box-shadow:-1px 0 #20a8b1!important}#bookmarksBox.mobile .bookmarkList li.bookmarkFolder ul{min-height:37px!important;display:none!important}#updatestatus .bkmrksStar{float:left;background:#262c32;margin:-25px 0 0 -5px;padding:0 3px 1px 4px}#bookmarksBox.mobile .bookmarkList .bookmarkFolder .folderLabel .bookmarksAnchor span,#bookmarksBox.mobile .bookmarkList .bookmarkFolder .folderLabel>span,#bookmarksBox.mobile .bookmarkList .bookmarkFolder .folderLabel>span>span,#bookmarksBox.mobile .bookmarkList .triangle{width:0!important;height:0!important}#bookmarksBox.mobile .bookmarkList .bookmarkFolder .folderLabel .bookmarksAnchor span{float:left!important;border-width:5px 0 5px 7px!important;border-color:#0000 #0000 #0000 #fff!important;margin:7px 3px 0 13px!important}#bookmarksBox.mobile .bookmarkList .bookmarkFolder.open .folderLabel .bookmarksAnchor span{border-width:7px 5px 0!important;border-color:#fff #0000 #0000!important;margin:9px 1px 0 12px!important}#bookmarksBox.mobile .bookmarkList .bookmarkFolder .folderLabel>span,#bookmarksBox.mobile .bookmarkList .bookmarkFolder .folderLabel>span>span{border-width:0 12px 10px 0!important;border-color:#0000 #20a8b1 #0000 #0000!important;margin:-20px 0 0 100%!important;display:none!important;position:relative!important;top:21px!important;left:-10px!important}#bookmarksBox.mobile .bookmarkList .bookmarkFolder .folderLabel>span>span{border-width:0 10px 9px 0!important;border-color:#0000 #069 #0000 #0000!important;top:18px!important;left:0!important}#bookmarksBox.mobile .bookmarkList .bookmarkFolder.open .folderLabel>span,#bookmarksBox.mobile .bookmarkList .bookmarkFolder.open .folderLabel>span>span{display:block!important}#bkmrksAutoDrawer,#bkmrksAutoDrawer p,#bkmrksAutoDrawer a{margin:0;padding:0;display:block}#bkmrksAutoDrawer .bookmarkFolder{border:1px solid #20a8b1;margin-bottom:4px}#bkmrksAutoDrawer .folderLabel{color:#fff;background:#069;padding:4px 0}#bkmrksAutoDrawer .bookmarkFolder div{background:#0000004d;border-top:1px solid #20a8b1;padding:6px 0}#bkmrksAutoDrawer .bookmarkFolder#idOthers .folderLabel{display:none}#bkmrksAutoDrawer .bookmarkFolder#idOthers div{border-top:none;display:block}#bkmrksAutoDrawer a{text-indent:10px;padding:2px 0}#bkmrksAutoDrawer .longdistance{color:#fc0;border-bottom:1px dashed;font-weight:700}#bkmrksAutoDrawer .bookmarkFolder div{display:none}#bkmrksAutoDrawer a.bkmrk.selected{color:#03dc03}#bookmarksBox.mobile a.bookmarksMoveIn{display:none!important}#bookmarksBox.mobile .bookmarkList ul li ul li.bkmrk a.bookmarksMoveIn{text-align:center;color:#fff;width:10%;background:0 0!important;box-shadow:inset 0 1px #20a8b1,inset -1px 0 #20a8b1!important}#bookmarksBox.mobile.moveMode a.bookmarksMoveIn{display:block!important}#bookmarksBox.moveMode ul .bookmarksLink,#bookmarksBox.moveMode ul .othersBookmarks .bookmarksLink{width:90%!important}.bookmarksDialog h3{text-transform:capitalize;margin-top:10px}.bookmarksDialog .bookmarkFolder{color:#fff;cursor:pointer;background:#069;border:1px solid #20a8b1;margin-bottom:4px;padding:4px 10px}.bookmarksDialog .bookmarkFolder:hover{text-decoration:underline}#bookmarksBox.mobile #topBar .btn{color:#fff;width:100%;padding-top:17px;font-size:13px;font-weight:400;text-indent:0!important;height:45px!important}#bookmarksBox.mobile .btn{background:#222;width:50%!important}#bookmarksBox.mobile .btn.left{border-right:1px solid #20a8b1!important}#bookmarksBox.mobile .btn#bookmarksMove{background:#b42e2e}').appendTo('head');
};

setup.info = plugin_info; //add the script info data to the function as a property
if (typeof changelog !== 'undefined') setup.info.changelog = changelog;
if(!window.bootPlugins) window.bootPlugins = [];
window.bootPlugins.push(setup);
// if IITC has already booted, immediately run the 'setup' function
if(window.iitcLoaded && typeof setup === 'function') setup();
} // wrapper end
// inject code into site context
var script = document.createElement('script');
var info = {};
if (typeof GM_info !== 'undefined' && GM_info && GM_info.script) info.script = { version: GM_info.script.version, name: GM_info.script.name, description: GM_info.script.description };
script.appendChild(document.createTextNode('('+ wrapper +')('+JSON.stringify(info)+');'));
(document.body || document.head || document.documentElement).appendChild(script);

