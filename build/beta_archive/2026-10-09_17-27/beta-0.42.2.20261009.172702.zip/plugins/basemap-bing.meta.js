// ==UserScript==
// @author         johnd0e
// @name           IITC plugin: Bing maps
// @category       Map Tiles
// @version        0.4.0.20261009.172702
// @description    Add the bing.com map layers.
// @id             basemap-bing
// @namespace      https://github.com/IITC-CE/ingress-intel-total-conversion
// @updateURL      https://iitc.app/build/beta/plugins/basemap-bing.meta.js
// @downloadURL    https://iitc.app/build/beta/plugins/basemap-bing.user.js
// @match          https://intel.ingress.com/*
// @match          https://intel-x.ingress.com/*
// @icon           https://iitc.app/extras/plugin-icons/basemap-bing.svg
// @grant          none
// ==/UserScript==
