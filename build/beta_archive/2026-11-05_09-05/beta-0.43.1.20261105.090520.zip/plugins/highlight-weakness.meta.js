// ==UserScript==
// @author         vita10gy
// @name           IITC plugin: Highlight portal weakness
// @category       Highlighter
// @version        0.8.4.20261105.090520
// @description    Use the fill color of the portals to denote if the portal is weak. Stronger red indicates recharge required, missing resonators, or both.
// @id             highlight-weakness
// @namespace      https://github.com/IITC-CE/ingress-intel-total-conversion
// @updateURL      https://iitc.app/build/beta/plugins/highlight-weakness.meta.js
// @downloadURL    https://iitc.app/build/beta/plugins/highlight-weakness.user.js
// @match          https://intel.ingress.com/*
// @match          https://intel-x.ingress.com/*
// @icon           https://iitc.app/extras/plugin-icons/highlight-weakness.svg
// @grant          none
// ==/UserScript==
