// ==UserScript==
// @author         breunigs
// @name           IITC plugin: Player activity tracker
// @category       Layer
// @version        0.14.1.20260319.074851
// @description    Draw trails for the path a user took onto the map based on status messages in COMMs. Uses up to three hours of data. Does not request chat data on its own, even if that would be useful.
// @id             player-activity-tracker
// @namespace      https://github.com/IITC-CE/ingress-intel-total-conversion
// @updateURL      https://iitc.app/build/artifact/PR896/plugins/player-activity-tracker.meta.js
// @downloadURL    https://iitc.app/build/artifact/PR896/plugins/player-activity-tracker.user.js
// @match          https://intel.ingress.com/*
// @match          https://intel-x.ingress.com/*
// @icon           https://iitc.app/extras/plugin-icons/player-activity-tracker.svg
// @grant          none
// ==/UserScript==
