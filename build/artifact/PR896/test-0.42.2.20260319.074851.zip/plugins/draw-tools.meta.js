// ==UserScript==
// @author         breunigs
// @name           IITC plugin: Draw tools
// @category       Draw
// @version        0.12.1.20260319.074851
// @description    Allow drawing things onto the current map so you may plan your next move. Supports Multi-Project-Extension.
// @id             draw-tools
// @namespace      https://github.com/IITC-CE/ingress-intel-total-conversion
// @updateURL      https://iitc.app/build/artifact/PR896/plugins/draw-tools.meta.js
// @downloadURL    https://iitc.app/build/artifact/PR896/plugins/draw-tools.user.js
// @match          https://intel.ingress.com/*
// @match          https://intel-x.ingress.com/*
// @icon           https://iitc.app/extras/plugin-icons/draw-tools.svg
// @grant          none
// ==/UserScript==
