// ==UserScript==
// @author         modos189
// @name           IITC plugin: Double-tap drag zoom
// @category       Controls
// @version        1.0.0.20261107.151130
// @description    Enable double-tap-and-drag gesture to zoom the map on touch devices
// @id             double-tap-drag-zoom
// @namespace      https://github.com/IITC-CE/ingress-intel-total-conversion
// @updateURL      https://iitc.app/build/artifact/PR980/plugins/double-tap-drag-zoom.meta.js
// @downloadURL    https://iitc.app/build/artifact/PR980/plugins/double-tap-drag-zoom.user.js
// @match          https://intel.ingress.com/*
// @match          https://intel-x.ingress.com/*
// @icon           https://iitc.app/extras/plugin-icons/double-tap-drag-zoom.svg
// @grant          none
// ==/UserScript==
