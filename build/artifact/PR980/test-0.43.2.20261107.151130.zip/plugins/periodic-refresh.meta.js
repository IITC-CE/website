// ==UserScript==
// @author         jonatkins
// @name           IITC plugin: Periodic refresh
// @category       Tweaks
// @version        0.1.3.20261107.151130
// @description    For use for unattended display screens only, this plugin causes idle mode to be left once per hour.
// @id             periodic-refresh
// @namespace      https://github.com/IITC-CE/ingress-intel-total-conversion
// @updateURL      https://iitc.app/build/artifact/PR980/plugins/periodic-refresh.meta.js
// @downloadURL    https://iitc.app/build/artifact/PR980/plugins/periodic-refresh.user.js
// @match          https://intel.ingress.com/*
// @match          https://intel-x.ingress.com/*
// @icon           https://iitc.app/extras/plugin-icons/periodic-refresh.svg
// @grant          none
// ==/UserScript==
