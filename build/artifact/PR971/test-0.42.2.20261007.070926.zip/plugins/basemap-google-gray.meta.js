// ==UserScript==
// @author         jacob1123
// @name           IITC plugin: Gray Google map
// @category       Map Tiles
// @version        0.1.8.20261007.070926
// @description    Add a simplified gray Version of Google map tiles as an optional layer.
// @id             basemap-google-gray
// @namespace      https://github.com/IITC-CE/ingress-intel-total-conversion
// @updateURL      https://iitc.app/build/artifact/PR971/plugins/basemap-google-gray.meta.js
// @downloadURL    https://iitc.app/build/artifact/PR971/plugins/basemap-google-gray.user.js
// @match          https://intel.ingress.com/*
// @match          https://intel-x.ingress.com/*
// @icon           https://iitc.app/extras/plugin-icons/basemap-google-gray.svg
// @grant          none
// ==/UserScript==
