// ==UserScript==
// @author         breunigs
// @name           IITC plugin: Scale bar
// @category       Controls
// @version        0.1.4.20260709.023603
// @description    Show scale bar on the map.
// @id             scale-bar
// @namespace      https://github.com/IITC-CE/ingress-intel-total-conversion
// @updateURL      https://iitc.app/build/artifact/PR937/plugins/scale-bar.meta.js
// @downloadURL    https://iitc.app/build/artifact/PR937/plugins/scale-bar.user.js
// @match          https://intel.ingress.com/*
// @match          https://intel-x.ingress.com/*
// @icon           https://iitc.app/extras/plugin-icons/scale-bar.svg
// @grant          none
// ==/UserScript==
