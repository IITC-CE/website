// ==UserScript==
// @author         morph
// @name           IITC plugin: Wayfarer portal submission range
// @category       Layer
// @version        0.2.0.20260709.023603
// @description    Add a 20m range around portals and drawn markers, to aid Wayfarer portals submissions
// @id             wayfarer-range
// @namespace      https://github.com/IITC-CE/ingress-intel-total-conversion
// @updateURL      https://iitc.app/build/artifact/PR937/plugins/wayfarer-range.meta.js
// @downloadURL    https://iitc.app/build/artifact/PR937/plugins/wayfarer-range.user.js
// @match          https://intel.ingress.com/*
// @match          https://intel-x.ingress.com/*
// @icon           https://iitc.app/extras/plugin-icons/wayfarer-range.svg
// @grant          none
// ==/UserScript==
