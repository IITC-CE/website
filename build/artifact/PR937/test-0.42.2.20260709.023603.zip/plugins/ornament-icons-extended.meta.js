// ==UserScript==
// @author         johtata
// @name           IITC plugin: Ornament icons extended
// @category       Layer
// @version        0.1.3.20260709.023603
// @description    Additonal icons and names for beacons
// @id             ornament-icons-extended
// @namespace      https://github.com/IITC-CE/ingress-intel-total-conversion
// @updateURL      https://iitc.app/build/artifact/PR937/plugins/ornament-icons-extended.meta.js
// @downloadURL    https://iitc.app/build/artifact/PR937/plugins/ornament-icons-extended.user.js
// @match          https://intel.ingress.com/*
// @match          https://intel-x.ingress.com/*
// @icon           https://iitc.app/extras/plugin-icons/ornament-icons-extended.svg
// @grant          none
// ==/UserScript==
