// ==UserScript==
// @author         xelio
// @name           IITC plugin: Keys
// @category       Misc
// @version        0.4.4.20260923.075953
// @description    Allow manual entry of key counts for each portal. Use the 'keys-on-map' plugin to show the numbers on the map, and 'sync' to share between multiple browsers or desktop/mobile.
// @id             keys
// @namespace      https://github.com/IITC-CE/ingress-intel-total-conversion
// @updateURL      https://iitc.app/build/artifact/PR970/plugins/keys.meta.js
// @downloadURL    https://iitc.app/build/artifact/PR970/plugins/keys.user.js
// @match          https://intel.ingress.com/*
// @match          https://intel-x.ingress.com/*
// @icon           https://iitc.app/extras/plugin-icons/keys.svg
// @grant          none
// ==/UserScript==
