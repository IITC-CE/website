// ==UserScript==
// @author         949
// @name           IITC plugin: Find farms on map
// @category       Layer
// @version        1.5.0.20261123.105018
// @description    Show farms by minimum level
// @id             farms-find
// @namespace      https://github.com/IITC-CE/ingress-intel-total-conversion
// @updateURL      https://iitc.app/build/artifact/PR1004/plugins/farms-find.meta.js
// @downloadURL    https://iitc.app/build/artifact/PR1004/plugins/farms-find.user.js
// @match          https://intel.ingress.com/*
// @match          https://intel-x.ingress.com/*
// @icon           https://iitc.app/extras/plugin-icons/farms-find.svg
// @grant          none
// ==/UserScript==
