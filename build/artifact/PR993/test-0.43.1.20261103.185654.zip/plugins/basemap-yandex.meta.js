// ==UserScript==
// @author         johnd0e
// @name           IITC plugin: Yandex maps
// @category       Map Tiles
// @version        0.3.5.20261103.185654
// @description    Add Yandex.com (Russian/Русский) map layers
// @id             basemap-yandex
// @namespace      https://github.com/IITC-CE/ingress-intel-total-conversion
// @updateURL      https://iitc.app/build/artifact/PR993/plugins/basemap-yandex.meta.js
// @downloadURL    https://iitc.app/build/artifact/PR993/plugins/basemap-yandex.user.js
// @match          https://intel.ingress.com/*
// @match          https://intel-x.ingress.com/*
// @icon           https://iitc.app/extras/plugin-icons/basemap-yandex.svg
// @grant          none
// ==/UserScript==
