// ==UserScript==
// @author         jonatkins
// @name           IITC plugin: Ingress scoring regions
// @category       Layer
// @version        0.3.5.20261103.185654
// @description    Show the regional scoring cells grid on the map
// @id             regions
// @namespace      https://github.com/IITC-CE/ingress-intel-total-conversion
// @updateURL      https://iitc.app/build/artifact/PR993/plugins/regions.meta.js
// @downloadURL    https://iitc.app/build/artifact/PR993/plugins/regions.user.js
// @match          https://intel.ingress.com/*
// @match          https://intel-x.ingress.com/*
// @icon           https://iitc.app/extras/plugin-icons/regions.svg
// @grant          none
// ==/UserScript==
