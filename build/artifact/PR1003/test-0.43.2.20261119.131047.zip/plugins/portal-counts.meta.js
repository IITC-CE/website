// ==UserScript==
// @author         yenky
// @name           IITC plugin: Portal count
// @category       Info
// @version        0.2.7.20261119.131047
// @description    Display a list of all localized portals by level and faction.
// @id             portal-counts
// @namespace      https://github.com/IITC-CE/ingress-intel-total-conversion
// @updateURL      https://iitc.app/build/artifact/PR1003/plugins/portal-counts.meta.js
// @downloadURL    https://iitc.app/build/artifact/PR1003/plugins/portal-counts.user.js
// @match          https://intel.ingress.com/*
// @match          https://intel-x.ingress.com/*
// @icon           https://iitc.app/extras/plugin-icons/portal-counts.svg
// @grant          none
// ==/UserScript==
