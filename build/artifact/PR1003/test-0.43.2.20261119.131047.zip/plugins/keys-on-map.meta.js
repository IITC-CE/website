// ==UserScript==
// @author         xelio
// @name           IITC plugin: Keys on map
// @category       Layer
// @version        0.3.5.20261119.131047
// @description    Show the manually entered key counts from the 'keys' plugin on the map.
// @id             keys-on-map
// @namespace      https://github.com/IITC-CE/ingress-intel-total-conversion
// @updateURL      https://iitc.app/build/artifact/PR1003/plugins/keys-on-map.meta.js
// @downloadURL    https://iitc.app/build/artifact/PR1003/plugins/keys-on-map.user.js
// @match          https://intel.ingress.com/*
// @match          https://intel-x.ingress.com/*
// @icon           https://iitc.app/extras/plugin-icons/keys-on-map.svg
// @grant          none
// ==/UserScript==
