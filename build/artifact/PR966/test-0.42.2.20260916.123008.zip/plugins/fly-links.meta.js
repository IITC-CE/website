// ==UserScript==
// @author         Fly33
// @name           IITC plugin: Fly Links
// @category       Draw
// @version        0.5.4.20260916.123008
// @description    Calculate how to link the portals to create the largest tidy set of nested fields. Enable from the layer chooser.
// @id             fly-links
// @namespace      https://github.com/IITC-CE/ingress-intel-total-conversion
// @updateURL      https://iitc.app/build/artifact/PR966/plugins/fly-links.meta.js
// @downloadURL    https://iitc.app/build/artifact/PR966/plugins/fly-links.user.js
// @match          https://intel.ingress.com/*
// @match          https://intel-x.ingress.com/*
// @icon           https://iitc.app/extras/plugin-icons/fly-links.svg
// @grant          none
// ==/UserScript==
