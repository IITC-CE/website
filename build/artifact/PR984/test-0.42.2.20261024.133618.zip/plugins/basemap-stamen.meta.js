// ==UserScript==
// @author         jonatkins
// @name           IITC plugin: Stamen.com map layers
// @category       Map Tiles
// @version        0.3.0.20261024.133618
// @description    Add the Stamen map layers, hosted by Stadia Maps.
// @id             basemap-stamen
// @namespace      https://github.com/IITC-CE/ingress-intel-total-conversion
// @updateURL      https://iitc.app/build/artifact/PR984/plugins/basemap-stamen.meta.js
// @downloadURL    https://iitc.app/build/artifact/PR984/plugins/basemap-stamen.user.js
// @match          https://intel.ingress.com/*
// @match          https://intel-x.ingress.com/*
// @icon           https://iitc.app/extras/plugin-icons/basemap-stamen.svg
// @grant          none
// ==/UserScript==
