// ==UserScript==
// @author         vita10gy
// @name           IITC plugin: Highlight portals missing resonators
// @category       Highlighter
// @version        0.2.5.20261123.120439
// @description    Use the portal fill color to denote if the portal is missing resonators.
// @id             highlight-missing-resonators
// @namespace      https://github.com/IITC-CE/ingress-intel-total-conversion
// @updateURL      https://iitc.app/build/artifact/PR1005/plugins/highlight-missing-resonators.meta.js
// @downloadURL    https://iitc.app/build/artifact/PR1005/plugins/highlight-missing-resonators.user.js
// @match          https://intel.ingress.com/*
// @match          https://intel-x.ingress.com/*
// @icon           https://iitc.app/extras/plugin-icons/highlight-missing-resonators.svg
// @grant          none
// ==/UserScript==
