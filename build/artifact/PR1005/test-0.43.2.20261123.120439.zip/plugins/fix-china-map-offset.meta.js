// ==UserScript==
// @author         modos189
// @name           IITC plugin: Fix maps offsets in China
// @category       Tweaks
// @version        0.3.4.20261123.120439
// @description    Show correct maps for China user by applying offset tweaks.
// @id             fix-china-map-offset
// @namespace      https://github.com/IITC-CE/ingress-intel-total-conversion
// @updateURL      https://iitc.app/build/artifact/PR1005/plugins/fix-china-map-offset.meta.js
// @downloadURL    https://iitc.app/build/artifact/PR1005/plugins/fix-china-map-offset.user.js
// @match          https://intel.ingress.com/*
// @match          https://intel-x.ingress.com/*
// @icon           https://iitc.app/extras/plugin-icons/fix-china-map-offset.svg
// @grant          none
// ==/UserScript==
