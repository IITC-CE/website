// ==UserScript==
// @author         vita10gy
// @name           IITC plugin: Hide portal ownership
// @category       Highlighter
// @version        0.2.4.20261123.120439
// @description    Show all portals as neutral, as if uncaptured. Great for creating plans.
// @id             highlight-hide-team
// @namespace      https://github.com/IITC-CE/ingress-intel-total-conversion
// @updateURL      https://iitc.app/build/artifact/PR1005/plugins/highlight-hide-team.meta.js
// @downloadURL    https://iitc.app/build/artifact/PR1005/plugins/highlight-hide-team.user.js
// @match          https://intel.ingress.com/*
// @match          https://intel-x.ingress.com/*
// @icon           https://iitc.app/extras/plugin-icons/highlight-hide-team.svg
// @grant          none
// ==/UserScript==
