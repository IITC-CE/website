// ==UserScript==
// @author         johnd0e
// @name           IITC plugin: Privacy view on Intel
// @category       Misc
// @version        1.2.2.20260614.072955
// @description    Hide info from intel which shouldn't leak to players of the other faction.
// @id             privacy-view
// @namespace      https://github.com/IITC-CE/ingress-intel-total-conversion
// @updateURL      https://iitc.app/build/artifact/PR922/plugins/privacy-view.meta.js
// @downloadURL    https://iitc.app/build/artifact/PR922/plugins/privacy-view.user.js
// @match          https://intel.ingress.com/*
// @match          https://intel-x.ingress.com/*
// @icon           https://iitc.app/extras/plugin-icons/privacy-view.svg
// @grant          none
// ==/UserScript==
