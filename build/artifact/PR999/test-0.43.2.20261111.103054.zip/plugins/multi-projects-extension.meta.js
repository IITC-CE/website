// ==UserScript==
// @author         ZasoGD
// @name           IITC plugin: Multi Projects Extension
// @category       Controls
// @version        0.2.0.20261111.103054
// @description    Create separated projects in some plugins.
// @id             multi-projects-extension
// @namespace      https://github.com/IITC-CE/ingress-intel-total-conversion
// @updateURL      https://iitc.app/build/artifact/PR999/plugins/multi-projects-extension.meta.js
// @downloadURL    https://iitc.app/build/artifact/PR999/plugins/multi-projects-extension.user.js
// @match          https://intel.ingress.com/*
// @match          https://intel-x.ingress.com/*
// @icon           https://iitc.app/extras/plugin-icons/multi-projects-extension.svg
// @grant          none
// ==/UserScript==
