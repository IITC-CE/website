// ==UserScript==
// @author         jonatkins
// @name           IITC plugin: Scoring cycle / checkpoint times
// @category       Info
// @version        0.2.3.20261009.183917
// @description    Show the times used for the septicycle and checkpoints for regional scoreboards.
// @id             score-cycle-times
// @namespace      https://github.com/IITC-CE/ingress-intel-total-conversion
// @updateURL      https://iitc.app/build/artifact/PR976/plugins/score-cycle-times.meta.js
// @downloadURL    https://iitc.app/build/artifact/PR976/plugins/score-cycle-times.user.js
// @match          https://intel.ingress.com/*
// @match          https://intel-x.ingress.com/*
// @icon           https://iitc.app/extras/plugin-icons/score-cycle-times.svg
// @grant          none
// ==/UserScript==
