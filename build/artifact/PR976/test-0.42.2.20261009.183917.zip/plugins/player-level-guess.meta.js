// ==UserScript==
// @author         breunigs
// @name           IITC plugin: Player level guess
// @category       Info
// @version        0.5.12.20261009.183917
// @description    Try to determine player levels from the data available in the current view.
// @id             player-level-guess
// @namespace      https://github.com/IITC-CE/ingress-intel-total-conversion
// @updateURL      https://iitc.app/build/artifact/PR976/plugins/player-level-guess.meta.js
// @downloadURL    https://iitc.app/build/artifact/PR976/plugins/player-level-guess.user.js
// @match          https://intel.ingress.com/*
// @match          https://intel-x.ingress.com/*
// @icon           https://iitc.app/extras/plugin-icons/player-level-guess.svg
// @grant          none
// ==/UserScript==
