// ==UserScript==
// @author         ZasoGD
// @name           IITC plugin: Multi Projects Extension
// @category       Controls
// @version        0.1.5.20260504.114023
// @description    Create separated projects in some plugins.
// @id             multi-projects-extension
// @namespace      https://github.com/IITC-CE/ingress-intel-total-conversion
// @updateURL      https://iitc.app/build/artifact/PR916/plugins/multi-projects-extension.meta.js
// @downloadURL    https://iitc.app/build/artifact/PR916/plugins/multi-projects-extension.user.js
// @match          https://intel.ingress.com/*
// @match          https://intel-x.ingress.com/*
// @icon           https://iitc.app/extras/plugin-icons/multi-projects-extension.svg
// @grant          none
// ==/UserScript==
